unit QSO_Entry;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Menus, StdCtrls,
  ExtCtrls, ComCtrls,lazsysutils, Main_Window, Character, Grids, lang_select, StrUtils, math;

type

  { TQSO_Entry_Form }

  TQSO_Entry_Form = class(TForm)
    Band_Entry_ListBox_2: TListBox;
    Date_Label: TLabel;
    Time_Label: TLabel;
    Callsign_Label: TLabel;
    RX_RST_Label: TLabel;
    Zone_Label: TLabel;
    QSO_Edit_Label: TLabel;
    Report_Entry_Edit: TEdit;
    Save_Entry_Button: TButton;
    Cancel_Entry_Button: TButton;
    Date_Entry_Edit: TEdit;
    Band_Entry_ListBox_1: TListBox;
    Mode_Entry_ListBox: TListBox;
    Time_Entry_Edit: TEdit;
    Callsign_Entry_Edit: TEdit;
    Zone_Entry_Edit: TEdit;
    Date_Time_Refresh_Timer: TTimer;
    procedure Band_Entry_1_ListBox_OnChange(Sender: TObject; User: boolean);
    procedure Band_Entry_2_ListBox_OnChange(Sender: TObject; User: boolean);
    procedure Band_Entry_Listbox1_OnKeyPress(Sender: TObject; var Key: char);
    procedure Band_Entry_Listbox2_OnKeyPress(Sender: TObject; var Key: char);
    procedure Callsign_Entry_Edit_OnChange(Sender: TObject);
    procedure Callsign_Entry_OnKeyPress(Sender: TObject; var Key: char);
    procedure Cancel_Entry_ButtonClick(Sender: TObject);
    procedure ComboBox1Change(Sender: TObject);
    procedure Date_Edit_OnKeyPress(Sender: TObject; var Key: char);
    procedure Date_Time_Refresh_TimerTimer(Sender: TObject);
    procedure Band_Entry_ListBox_1Click(Sender: TObject);
    procedure Band_Entry_ListBox_2Click(Sender: TObject);
    procedure Entry_Form_OnCreate(Sender: TObject);
    procedure Callsign_LabelClick(Sender: TObject);
    procedure Mode_Entry_ListBoxClick(Sender: TObject);
    procedure Mode_Entry_Listbox_OnKeyPress(Sender: TObject; var Key: char);
    procedure Program_OnClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure QSO_Entry_Form_OnKey_Down(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure QSO_Entry_Form_OnShow(Sender: TObject);
    procedure Report_Entry_EditChange(Sender: TObject);
    procedure Report_Entry_OnKeyPress(Sender: TObject; var Key: char);
    procedure Time_Edit_OnKeyPress(Sender: TObject; var Key: char);
    procedure Zone_Entry_OnKeyPress(Sender: TObject; var Key: char);
    procedure Zone_OnChange(Sender: TObject);
    procedure Save_Entry_ButtonClick(Sender: TObject);
    procedure Dupe_Check(Sender: TObject);


  private

  public

  end;

var
  QSO_Entry_Form: TQSO_Entry_Form;


implementation
uses log_setup;

{$R *.lfm}

{ TQSO_Entry_Form }

procedure TQSO_Entry_Form.ComboBox1Change(Sender: TObject);
begin

end;

procedure TQSO_Entry_Form.Date_Edit_OnKeyPress(Sender: TObject; var Key: char);
begin
  if not (Key in ['0'..'9', '-', #8, #27]) then Key := #0
  else if (Key = #27) then Cancel_Entry_ButtonClick(Nil)
  else if ((Length(Date_Entry_Edit.Text) > 9) and (Key <> #8)) then Key := #0;
  Dupe_Check(Nil);
end;

procedure TQSO_Entry_Form.Cancel_Entry_ButtonClick(Sender: TObject);
begin
  Callsign_Entry_Edit.Text := '';
  Zone_Entry_Edit.Text := '';
  QSO_Entry_Form.Date_Time_Refresh_Timer.Enabled := True;    // Stop tme and QSO_Entry_Form update timer
  Main_Form.Enabled := True;
  QSO_Entry_Form.SetFocus;
  QSO_Entry_Form.Color := clDefault;
  QSO_Entry_Form.Time_Entry_Edit.Enabled := False;
  QSO_Entry_Form.Date_Entry_Edit.Enabled := False;
  QSO_Entry_Form.Save_Entry_Button.Caption := sSave_Entry_Button[language];
  QSO_Entry_Form.Cancel_Entry_Button.Caption := sCancel_Entry_Button[language];
  QSO_Entry_Form.QSO_Edit_Label.Caption := sQSO_Edit_Label[language];
  QSO_Entry_Form.QSO_Edit_Label.Color := $0076C008;
  qso_in_edit_flag := False;
  Callsign_Entry_Edit.SetFocus;
  Dupe_Check(Nil);    // Will return the entry window to standard color.
end;

procedure TQSO_Entry_Form.Callsign_Entry_OnKeyPress(Sender: TObject; var Key: char);
begin
  // Validate key pressed as part of allowed callsign characters
  if not (Key in ['A'..'Z', 'a'..'z', '0'..'9', '/', #8, #13, #27, #32]) then Key := #0
  else if ((Key in ['A'..'Z', 'a'..'z', '0'..'9', '/', #13, #32]) and (length(Callsign_Entry_Edit.Text) > 11)) then                                         // Limits length to 12 characters by truncating the last character
  begin
       Application.MessageBox(PChar(IfThen(french_lang,'L''indicatif ne peut pas avoir plus de 12 caractères.', 'The callsign canot have more than 12 characters')), PChar(IfThen(french_lang,'Erreur de Saisie', 'Entry Error')), $00000010);
       Key := #0;
  end
  else if (Key = #13) then Save_Entry_ButtonClick(Nil)             // Check if return key pressed.
  else if (Key = #32) then
  begin
    Key := #0;
    Report_Entry_Edit.SetFocus;
  end
  else if (Key = #27) then Cancel_Entry_ButtonClick(Nil)
  else if (Key in ['a'..'z']) then Key := UpCase(Key);
end;

procedure TQSO_Entry_Form.Band_Entry_1_ListBox_OnChange(Sender: TObject;
  User: boolean);
begin
end;

procedure TQSO_Entry_Form.Band_Entry_2_ListBox_OnChange(Sender: TObject;
  User: boolean);
begin
end;

procedure TQSO_Entry_Form.Band_Entry_Listbox1_OnKeyPress(Sender: TObject;
  var Key: char);
begin
  if (key = #32) then Callsign_Entry_Edit.SetFocus;
  if (key <> #9) then Key := #0;     // Inhibits a string search by the user
end;

procedure TQSO_Entry_Form.Band_Entry_Listbox2_OnKeyPress(Sender: TObject;
  var Key: char);
begin
  if (key = #32) then Callsign_Entry_Edit.SetFocus;
  if (key <> #9) then Key := #0;     // Inhibits a string search by the user
end;

procedure TQSO_Entry_Form.Callsign_Entry_Edit_OnChange(Sender: TObject);
begin
     Dupe_Check(Nil);
end;

procedure TQSO_Entry_Form.Date_Time_Refresh_TimerTimer(Sender: TObject);
Var ThisMoment : TDateTime;
begin
     ThisMoment := NowUTC();
     Time_Entry_Edit.Text := FormatDateTime('hh:nn',ThisMoment);
     Date_Entry_Edit.Text := FormatDateTime('YYYY/MM/DD',ThisMoment);
end;

procedure TQSO_Entry_Form.Band_Entry_ListBox_1Click(Sender: TObject);
begin
     Band_Entry_ListBox_2.ClearSelection;
     Dupe_Check(Nil);
end;

procedure TQSO_Entry_Form.Band_Entry_ListBox_2Click(Sender: TObject);
begin
     Band_Entry_ListBox_1.ClearSelection;
     Dupe_Check(Nil);
end;

procedure TQSO_Entry_Form.Entry_Form_OnCreate(Sender: TObject);
begin
    Mode_Entry_ListBox.ItemIndex := 0;
    Band_Entry_ListBox_1.ItemIndex := 0;
    Band_Entry_ListBox_2.ItemIndex := -1;
    Report_Entry_Edit.Text := '59';
end;

procedure TQSO_Entry_Form.Callsign_LabelClick(Sender: TObject);
begin

end;

procedure TQSO_Entry_Form.Mode_Entry_ListBoxClick(Sender: TObject);
begin
  if (Mode_Entry_ListBox.items[Mode_Entry_ListBox.ItemIndex] = 'CW') then Report_Entry_Edit.Text := '599' else Report_Entry_Edit.Text := '59';
  Dupe_Check(Nil);
end;

procedure TQSO_Entry_Form.Mode_Entry_Listbox_OnKeyPress(Sender: TObject;
  var Key: char);
begin
     if (key = #32) then Callsign_Entry_Edit.SetFocus;
     if (key <> #9) then Key := #0;           // Inhibits a string search by the user
end;

procedure TQSO_Entry_Form.Program_OnClose(Sender: TObject;
  var CloseAction: TCloseAction);
begin
     Main_Form.Save_Config_File(Nil);
     Application.Terminate;
end;

procedure TQSO_Entry_Form.QSO_Entry_Form_OnKey_Down(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  begin
     if (((Key = ord('e')) or (Key = ord('E'))) and (Shift = [ssCtrl])) then       // Edit highlighted QSO
     begin
       Key := 0;
       Main_Form.Edit_QSO_MenuItemClick(Nil);
     end;
     if (((Key = ord('r')) or (Key = ord('R'))) and (Shift = [ssCtrl])) then       // Re-use highlighted QSO
     begin
       Key := 0;
       Main_Form.ReuseQSO_MenuItemClick(Nil);
     end;
  end;
end;

procedure TQSO_Entry_Form.QSO_Entry_Form_OnShow(Sender: TObject);
begin
end;

procedure TQSO_Entry_Form.Report_Entry_EditChange(Sender: TObject);
begin

end;

procedure TQSO_Entry_Form.Report_Entry_OnKeyPress(Sender: TObject; var Key: char);
begin
  // Validate key pressed as part of allowed RS(T) characters
  if not (Key in ['1'..'9', #8, #13, #27, #32]) then Key := #0
  else if (Key = #32) then
  begin
    Key := #0;
    Zone_Entry_Edit.SetFocus;
  end
  else if (Key = #13) then
  begin
    Key := #0;
    Save_Entry_ButtonClick(Nil);             // Check if return key pressed.
  end
  else if (Key = #27) then Cancel_Entry_ButtonClick(Nil)
  else if ((IsNumber(Key)) and (((Length(Report_Entry_Edit.Text) > 2) and (Mode_Entry_ListBox.Items[Mode_Entry_ListBox.ItemIndex] = 'CW'))        // Limits to 2 characters in CW
                                 or ((Length(Report_Entry_Edit.Text) > 1) and (Mode_Entry_ListBox.Items[Mode_Entry_ListBox.ItemIndex] <> 'CW')))) // Limits to three characters in SSB
  then Key := #0
  else if ((IsNumber(Key) and (Report_Entry_Edit.Text <> '') and not(StrToInt(Copy(Report_Entry_Edit.Text,0,1)) in [1..5]))) then Key := #0       // Limits first digit to 1-5 when there are already characters entered
  else if ((IsNumber(Key) and (Report_Entry_Edit.Text = '') and not(StrToInt(Key) in [1..5]))) then Key := #0                                     // Limits first digit to 1-5 when there are no characters entered
end;

procedure TQSO_Entry_Form.Time_Edit_OnKeyPress(Sender: TObject; var Key: char);
begin
  if not (Key in ['0'..'9', ':', #8, #27]) then Key := #0
  else if (Key = #27) then Cancel_Entry_ButtonClick(Nil)
  else if ((Length(Time_Entry_Edit.Text) > 4)  and (Key <> #8)) then Key := #0;
end;

procedure TQSO_Entry_Form.Zone_Entry_OnKeyPress(Sender: TObject; var Key: char);
begin
  // Validate key pressed as part of allowed Zone characters
  if not (Key in ['A'..'Z', 'a'..'z', #8, #13, #27, #32]) then Key := #0
  else if (Key = #13) then Save_Entry_ButtonClick(Nil)             // Check if return key pressed.
  else if (Key = #32) then
  begin
    Key := #0;
    Callsign_Entry_Edit.SetFocus;
  end
  else if (Key = #27) then Cancel_Entry_ButtonClick(Nil)
  else if (Key in ['a'..'z']) then Key := UpCase(Key);
  if ((IsLetterOrDigit(Key)) and (Length(Zone_Entry_Edit.Text) > 2)) then Key := #0;
end;

procedure TQSO_Entry_Form.Zone_OnChange(Sender: TObject);
begin
  Dupe_Check(Nil);
end;

procedure TQSO_Entry_Form.Save_Entry_ButtonClick(Sender: TObject);
var
  datetime, band, mode, callsign, rst, zone, party, myzone: String;
begin
  Dupe_Check(Nil);
  if (Callsign_Entry_Edit.Text = Log_Setup_Form.Station_Callsign_LabeledEdit.Text) then         // Check if trying to enter a QSO with its own callsign (a QSO with self)
  begin
    Application.MessageBox(PChar(IfThen(french_lang,'Vous ne pouvez pas saisir un QSO avec vous-même!','You are not allowed to enter a QSO with yourself!')), PChar(IfThen(french_lang,'Erreur de Saisie','Entry Error')), $00000010);
    Callsign_Entry_Edit.Text := '';
    Callsign_Entry_Edit.SetFocus;
  end
  else if (((not(InRange(StrToInt(Report_Entry_Edit.Text),111,599))) and (Mode_Entry_ListBox.items[Mode_Entry_ListBox.ItemIndex] = 'CW'))           // A required final verification on the signal report
      or ((not(InRange(StrToInt(Report_Entry_Edit.Text),11,59))) and (not(Mode_Entry_ListBox.items[Mode_Entry_ListBox.ItemIndex] = 'CW')))) then
  begin
    Application.MessageBox(PChar(IfThen(french_lang,'Le format du Signal RS(T) du QSO est erronné. Veillez le saisir de nouveau.','The RS(T) signal format is erroneous. Please enter it again.')), PChar(IfThen(french_lang,'Erreur de Saisie','Entry Error')), $00000010);
    Report_Entry_Edit.Text := '';
    Report_Entry_Edit.SetFocus;
  end
  else if (not(dupe_found)
          or ((dupe_found) and (not(qso_in_edit_flag)) and (MessageDlg(PChar(IfThen(french_lang,'QSO en Double','Duplicate QSO')), PChar(IfThen(french_lang,'Un QSO "doublon" existe déjà. Voulez-vous quand même le saisir?',
                                                                       'A duplicate QSO already exists. Do you still want to log it?')), mtConfirmation, [mbYes, mbNo],1) = mrYes))
          or ((dupe_found) and (qso_in_edit_flag)))
       then
  begin
    datetime := Concat(Date_Entry_Edit.Text,'_',Time_Entry_Edit.Text);
    if (Band_Entry_ListBox_1.ItemIndex = -1) then band := Band_Entry_ListBox_2.items[Band_Entry_ListBox_2.ItemIndex] else band := Band_Entry_ListBox_1.items[Band_Entry_ListBox_1.ItemIndex];
    mode := Mode_Entry_ListBox.items[Mode_Entry_ListBox.ItemIndex];
    callsign := Callsign_Entry_Edit.Text;
    rst := Report_Entry_Edit.Text;
    zone := Zone_Entry_Edit.Text;
    myzone := Log_Setup_Form.Zone_ComboBox.Text;
    party := Log_Setup_Form.Party_Select_RadioGroup.Items[Log_Setup_Form.Party_Select_RadioGroup.ItemIndex];
    if ((callsign = '') or (rst  = '') or (zone = '') or (Length(callsign) < 3) or (Length(zone) < 2) or (Length(rst) < 2)) then
       Application.MessageBox(PChar(IfThen(french_lang,'L''information du QSO est incomplète ou erronnée.','The QSO data is incomplete or erroneous')), PChar(IfThen(french_lang,'Erreur de Saisie', 'Entry Error')), $00000010)
    else if ((((Log_Setup_Form.Party_Select_RadioGroup.ItemIndex  in [0,2]) and (zone = 'QC')) and (MessageDlg(PChar(IfThen(french_lang,'Zone Non Valide', 'Non-Valid Zone')), PChar(IfThen(french_lang, 'Zone non valide. Ce QSO avec la zone "QC" ne sera pas comptabilisé dans le Québec QSO Party. Voulez-vous quand même le saisir?',
                              'Invalid Zone. This QSO with Zone "QC" will not be counted as part of the Québec QSO Party. Do you still want to log it?')), mtConfirmation, [mbYes, mbNo],1) = mrYes))
    or (((Log_Setup_Form.Party_Select_RadioGroup.ItemIndex  in [1,2]) and (zone = 'ON')) and (MessageDlg(PChar(IfThen(french_lang,'Zone Non Valide', 'Non-Valid Zone')), PChar(IfThen(french_lang, 'Zone non valide. Ce QSO avec la zone "ON" ne sera pas comptabilisé dans le Ontario QSO Party. Voulez-vous quand même le saisir?',
                              'Invalid Zone. This QSO with Zone "ON" will not be counted as part of the Ontario QSO Party. Do you still want to log it?')), mtConfirmation, [mbYes, mbNo],1) = mrYes))
    or ((Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 0) and (zone = 'ON'))
    or ((Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 1) and (zone = 'QC'))
    or ((zone <> 'QC') and (zone <> 'ON'))) then
    begin
      if (qso_in_edit_flag) then
      begin
           Main_Form.QSO_List_PopupMenu.Close;
           Main_Form.QSO_List_StringGrid.DeleteRow(Main_Form.QSO_List_StringGrid.Row);
           Main_Form.QSO_List_StringGrid.InsertRowWithValues(Main_Form.QSO_List_StringGrid.RowCount,[datetime, band, mode, callsign, rst, zone, party, myzone]);
           if (Main_Form.QSO_List_StringGrid.RowCount > 2) then Main_Form.QSO_List_StringGrid.Row := Main_Form.QSO_List_StringGrid.Row - 1;  // Repositions the highlight on the edited line only if there is more than one entry
           QSO_Entry_Form.Date_Time_Refresh_Timer.Enabled := True;    // Stop tme and QSO_Entry_Form update timer
           Main_Form.Enabled := True;
           QSO_Entry_Form.SetFocus;
           QSO_Entry_Form.Color := clDefault;
           QSO_Entry_Form.Time_Entry_Edit.Enabled := False;
           QSO_Entry_Form.Date_Entry_Edit.Enabled := False;
           QSO_Entry_Form.Save_Entry_Button.Caption := sSave_Entry_Button[language];
           QSO_Entry_Form.Cancel_Entry_Button.Caption := sCancel_Entry_Button[language];
           QSO_Entry_Form.QSO_Edit_Label.Caption := sQSO_Edit_Label[language];
           QSO_Entry_Form.QSO_Edit_Label.Color := $0076C008;
           qso_in_edit_flag := False;
      end
      else Main_Form.QSO_List_StringGrid.InsertRowWithValues(1,[datetime, band, mode, callsign, rst, zone, party, myzone]);
      Main_Form.QSO_List_StringGrid.Row := 0;
      Main_Form.Save_Log(Nil);
      Callsign_Entry_Edit.Text := '';
      Zone_Entry_Edit.Text := '';
      if (Mode_Entry_ListBox.items[Mode_Entry_ListBox.ItemIndex] = 'CW') then Report_Entry_Edit.Text := '599' else Report_Entry_Edit.Text := '59';
      Callsign_Entry_Edit.SetFocus;
      QSO_Entry_Form.Color := clDefault;
      dupe_found := False;
    end;
  end;
end;

procedure TQSO_Entry_Form.Dupe_Check(Sender: TObject);
var
   row_index: Integer;
   array_index: Integer;
   row_index_delta: Integer;
   temp: String;
begin
  if dupe_check_enabled then
  begin
    Main_Form.Dupe_QSO_List_StringGrid.SelectedColor := $0071D1;
    for row_index := 1 to (Main_Form.Dupe_QSO_List_StringGrid.RowCount - 1) do Main_Form.Dupe_QSO_List_StringGrid.DeleteRow(1);
    for row_index := 1 to (Main_Form.QSO_List_StringGrid.RowCount - 1) do
    begin
         if ((Callsign_Entry_Edit.Text = Main_Form.QSO_List_StringGrid.Cells[3,row_index])    // Callsign check
            and (Zone_Entry_Edit.Text = Main_Form.QSO_List_StringGrid.Cells[5,row_index])    // Zone check
            and ((((Mode_Entry_ListBox.Items[Mode_Entry_ListBox.ItemIndex] = 'FM')
                       or (Mode_Entry_ListBox.Items[Mode_Entry_ListBox.ItemIndex] = 'SSB'))           // Mode
                    and ((Main_Form.QSO_List_StringGrid.Cells[2,row_index] = 'FM')
                       or (Main_Form.QSO_List_StringGrid.Cells[2,row_index] = 'SSB')))     //  "
                  or ((Mode_Entry_ListBox.Items[Mode_Entry_ListBox.ItemIndex] = 'CW')             //  "
                          and (Main_Form.QSO_List_StringGrid.Cells[2,row_index] = 'CW')))              //  "
            and (((Band_Entry_ListBox_1.ItemIndex <> -1) and (Band_Entry_ListBox_1.Items[Band_Entry_ListBox_1.ItemIndex] = Main_Form.QSO_List_StringGrid.Cells[1,row_index]))     // Band
                 or ((Band_Entry_ListBox_2.ItemIndex <> -1) and (Band_Entry_ListBox_2.Items[Band_Entry_ListBox_2.ItemIndex] = Main_Form.QSO_List_StringGrid.Cells[1,row_index]))) //  "
            and (Log_Setup_Form.Party_Select_RadioGroup.Items[Log_Setup_Form.Party_Select_RadioGroup.ItemIndex] = Main_Form.QSO_List_StringGrid.Cells[6,row_index])     // QC or ON Party
            and (((Log_Setup_Form.Zone_ComboBox.Text) = Main_Form.QSO_List_StringGrid.Cells[7,row_index]))) then     // My Zone
         begin
            Main_Form.Dupe_QSO_List_StringGrid.InsertRowWithValues(1,[Main_Form.QSO_List_StringGrid.Cells[0,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[1,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[2,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[3,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[4,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[5,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[6,row_index],
                                                                      Main_Form.QSO_List_StringGrid.Cells[7,row_index]]);
         end;
    end;
    // This section displays the dupe contacts in the contact list
    if (Main_Form.Dupe_QSO_List_StringGrid.RowCount > 1) then
    begin
      dupe_found := True;
      QSO_Entry_Form.Color := $0071D1;    // DarkOrange
      Main_Form.Dupe_QSO_List_StringGrid.Visible := True;
      Main_Form.QSO_List_StringGrid.Visible := False;
      Main_Form.Top_Botton_Panel.Visible := False;
      Main_Form.Bottom_Botton_Panel.Visible := False;
//      if (qso_in_edit_flag) then QSO_Entry_Form.Save_Entry_Button.Enabled := False;
      //if (qso_in_edit_flag
      //    and (Date_Entry_Edit.Text = copy(Main_Form.QSO_List_StringGrid.Cells[0,row_index], 0,10))
      //    and (Time_Entry_Edit.Text = copy(Main_Form.QSO_List_StringGrid.Cells[0,row_index],12,5)))
      // then QSO_Entry_Form.Save_Entry_Button.Enabled := False;
    end
    else begin
      QSO_Entry_Form.Color := clDefault;
      dupe_found := False;
      Main_Form.Dupe_QSO_List_StringGrid.Visible := False;
      Main_Form.QSO_List_StringGrid.Visible := True;
      Main_Form.Top_Botton_Panel.Visible := True;
      Main_Form.Bottom_Botton_Panel.Visible := True;
//      if (qso_in_edit_flag) then QSO_Entry_Form.Save_Entry_Button.Enabled := True;
    end;
  end;
end;


end.

