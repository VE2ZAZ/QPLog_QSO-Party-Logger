unit qc_cab_editor;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Main_Window, cabrillo_file_editor_frame, StrUtils;

type

  { TQC_Cab_Edit_Form }

  TQC_Cab_Edit_Form = class(TForm)
    QC_Cabrillo_File_Editor_Frame: TCabrillo_File_Editor_Frame;
    procedure Cabrillo_Close_ButtonClick(Sender: TObject);
    procedure Cabrillo_Save_Changes_ButtonClick(Sender: TObject);
    procedure QC_Cab_Edit_Form_OnShow(Sender: TObject);
  private

  public

  end;

var
  QC_Cab_Edit_Form: TQC_Cab_Edit_Form;

implementation

{$R *.lfm}

{ TQC_Cab_Edit_Form }

procedure TQC_Cab_Edit_Form.Cabrillo_Save_Changes_ButtonClick(Sender: TObject);
begin
  QC_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Lines.SaveToFile(qc_cab_file_name);
  QC_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Modified := False;
end;

procedure TQC_Cab_Edit_Form.Cabrillo_Close_ButtonClick(Sender: TObject);
begin
  if (QC_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Modified) and (MessageDlg(PChar(IfThen(french_lang,'Sauvegarde du Cabrillo', 'Cabrillo Save')), PChar(IfThen(french_lang, 'Des modifications non-sauvegardées ont été apportées au fichier Cabrillo. Voulez-vous sauvegarder ces changements?',
                       'Unsaved changes were made to this Cabrillo file. Do you want to save them?')), mtConfirmation, [mbYes, mbNo],1) = mrYes) then          begin
      QC_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Lines.SaveToFile(qc_cab_file_name);
  end;
  QC_Cab_Edit_Form.Visible := False;
end;

procedure TQC_Cab_Edit_Form.QC_Cab_Edit_Form_OnShow(Sender: TObject);
begin
  QC_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Lines.LoadFromFile(qc_cab_file_name);
  QC_Cab_Edit_Form.Caption := 'QUÉBEC QSO PARTY CABRILLO';
  QC_Cab_Edit_Form.Left := Main_Form.Left + 10;
  QC_Cab_Edit_Form.Top := Main_Form.Top + 10;
end;

end.

