unit Splashscreen;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls;

type

  { TSplash_Form }

  TSplash_Form = class(TForm)
    Splashscreen_Timer: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Splashscreen_TimerTimer(Sender: TObject);
  private

  public

  end;

var
  Splash_Form: TSplash_Form;

implementation

{$R *.lfm}

{ TSplash_Form }

procedure TSplash_Form.FormCreate(Sender: TObject);
begin

end;

procedure TSplash_Form.FormShow(Sender: TObject);
begin
     Splashscreen_Timer.Enabled := True;
end;

procedure TSplash_Form.Splashscreen_TimerTimer(Sender: TObject);
begin
     Splashscreen_Timer.Enabled := False;
     Splash_Form.Visible := False;
end;

end.

