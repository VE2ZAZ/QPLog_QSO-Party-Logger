program QSO_Party_Logger;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  {$IFDEF HASAMIGA}
  athreads,
  {$ENDIF}
  Interfaces, // this includes the LCL widgetset
  Forms, Main_Window, QSO_Entry, Launch_Splashscreen, worked_zones, log_setup,
  stats_form, qc_cab_editor, cabrillo_file_editor_frame, on_cab_editor,
  lang_select, SandBox;

{$R *.res}


begin
  RequireDerivedFormResource:=True;
  Application.Scaled:=True;
  Application.Initialize;
  Application.CreateForm(TMain_Form, Main_Form);
  Application.CreateForm(TQSO_Entry_Form, QSO_Entry_Form);
  Application.CreateForm(TWorked_Zones_Form, Worked_Zones_Form);
  Application.CreateForm(TLog_Setup_Form, Log_Setup_Form);
  Application.CreateForm(TStats_Form, Statistics_Form);
  Application.CreateForm(TQC_Cab_Edit_Form, QC_Cab_Edit_Form);
  Application.CreateForm(TON_Cab_Edit_Form, ON_Cab_Edit_Form);
  Main_Form.Load_Config_File(Nil);
  Application.CreateForm(TLaunch_Splash_Form, Launch_Splash_Form);
  Application.CreateForm(TSoapBox_Form, SoapBox_Form);
  Application.Run;
end.

