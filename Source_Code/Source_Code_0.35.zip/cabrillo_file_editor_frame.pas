unit cabrillo_file_editor_frame;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, ExtCtrls, StdCtrls, Main_Window;

type

  { TCabrillo_File_Editor_Frame }

  TCabrillo_File_Editor_Frame = class(TFrame)
    Cabrillo_Save_Changes_Button: TButton;
    Cabrillo_Close_Button: TButton;
    Cabrillo_Button_Panel: TPanel;
    Cab_Edit_Form_Memo: TMemo;
    procedure Cabrillo_Save_Changes_ButtonClick(Sender: TObject);
    procedure Cabrillo_Close_ButtonClick(Sender: TObject);
  private

  public

  end;

implementation

{$R *.lfm}

{ TCabrillo_File_Editor_Frame }

procedure TCabrillo_File_Editor_Frame.Cabrillo_Save_Changes_ButtonClick(Sender: TObject);
begin

end;

procedure TCabrillo_File_Editor_Frame.Cabrillo_Close_ButtonClick(Sender: TObject);
begin

end;

end.

