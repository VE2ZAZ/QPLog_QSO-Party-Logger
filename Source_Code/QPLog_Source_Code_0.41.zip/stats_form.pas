unit stats_form;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Grids, Main_Window, QSO_Entry;

type

  { TStats_Form }

  TStats_Form = class(TForm)
    Stats_StringGrid: TStringGrid;
    Timer1: TTimer;
    procedure Stats_Form_OnKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Stats_Form_OnShow(Sender: TObject);
    procedure Stats_StringGrid_OnPrepareCanvas(Sender: TObject; aCol,
      aRow: Integer; aState: TGridDrawState);
    procedure Timer1_OnTimer(Sender: TObject);
  private

  public

  end;

var
  Statistics_Form: TStats_Form;

implementation

{$R *.lfm}

{ TStats_Form }

procedure TStats_Form.Stats_Form_OnShow(Sender: TObject);
begin
  Main_Form.CompileStats(Nil);
end;

procedure TStats_Form.Stats_Form_OnKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
     if (Key in [112..123]) then        // One of F1-F12 Function keys pressed.
     begin
       QSO_Entry_Form.Send_Keyer_Command(IntToStr(Ord(Key)));
     end;
     if ((Key = 27) and (Keyer_Support_Present)) then QSO_Entry_Form.Send_Keyer_Command('27');         // Escape key pressed, send Escape code to keyer to stop CW.
     Key:= 0;
end;

procedure TStats_Form.Stats_StringGrid_OnPrepareCanvas(Sender: TObject; aCol,
  aRow: Integer; aState: TGridDrawState);
begin
  Stats_StringGrid.ColWidths[0] := 300;          // Adjusts the column header width to fit text
end;

procedure TStats_Form.Timer1_OnTimer(Sender: TObject);
begin
     Main_Form.CompileStats(Nil);
end;

end.

