unit Main_Window;

{
Version History:
================
 0.41 (2026-03-31)
   - Corrected a bug in generating the Cabrillo file in Windows. The Cabrillo file name now uses - instead of / as separator for the date.
 0.40 (2026-03-18)
   - Added support for the WinKeyer3 and for CW sending via the DTR or the RTS line on a serial port.
       - CW generaton is done using an add-on program: CW_Support
       - The F1 to F12 function keys are now assigned to CW operation.
   - 2026 Ontario QSO party: Added VE3RHQ as bonus station. Also, phone QSOs are now worth 2 points, the same as CW QSOs.
   - CTRL-W is added as key combination to clear the QSO entry fields.
   - Updated the user manual to add a CW generation section.
 0.35 (2026-02-28)
   - Cabrillo file now makes the distinction between 'SSB' and 'FM', formerly both were shown as 'PH'.
   - A QSO with themself (using its own callsign as the other station's callsign) is now rejected. A popup error window informs the user.
   - The date format is now standardized throughout the program as YYYY-MM-DD.
   - In the Cabrillo file, the "CREATED-BY: ..." information now begins with the word "QPLog", which allows the QSO Party organisers to easily identify the source and compile statistics.
   - In the setup window, the callsign is now forced to uppercase.
 0.34 (2025-04-17):
   - Includes a Cabrillo to ADIF file converter program (standalone program),
   - Fixes various Cabrillo generation bugs (soapbox handling, incorrect frequency format for 50 and 144 MHz, missing fields in Cab file).
 0.33 (2025-04-17): Corrects the inaccurate operator's zone in the Cabrillo file
 0.32 (2025-01-21): Initial Release
}


{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Grids, StdCtrls,
  ExtCtrls, Menus, StrUtils, FileUtil, LCLIntf,lNetComponents, DateUtils,
  lNet, Character, lazlogger, blcksock, synsock;

type

  { TMain_Form }

  TMain_Form = class(TForm)
    About_Button: TButton;
    Cabrillo_Button: TButton;
    Config_Log_Button: TButton;
    Copy_Log_Button: TButton;
    Edit_QSO_Button: TButton;
    Edit_QSO_Buttton: TButton;
    Erase_All_Button: TButton;
    Reuse_Button: TButton;
    Erase_QSO_Button: TButton;
    Help_Button: TButton;
    Load_Log_Button: TButton;
    Edit_QSO_MenuItem: TMenuItem;
    EraseQSO_MenuItem: TMenuItem;
    EraseAllQSOs_MenuItem: TMenuItem;
    ReuseQSO_MenuItem: TMenuItem;
    New_Log_Button: TButton;
    Log_Load_OpenDialog: TOpenDialog;
    Dupe_QSO_List_StringGrid: TStringGrid;
    QSO_List_PopupMenu: TPopupMenu;
    Separator1: TMenuItem;
    Stats_Button: TButton;
    Socket_Rx_Timer: TTimer;
    Top_Botton_Panel: TPanel;
    Bottom_Botton_Panel: TPanel;
    QSO_List_StringGrid: TStringGrid;
    Log_Create_SaveDialog: TSaveDialog;
    Log_Rename_SaveDialog: TSaveDialog;
    Language_Button: TButton;
    Worked_Zones_Button: TButton;
    procedure About_ButtonClick(Sender: TObject);
    procedure Cabrillo_ButtonClick(Sender: TObject);
    procedure Config_Log_ButtonClick(Sender: TObject);
//    procedure CW_Interface_RX_LUDPComponent_OnReceive(aSocket: TLSocket);
    procedure Edit_QSO_ButtonClick(Sender: TObject);
    procedure Edit_QSO_MenuItemClick(Sender: TObject);
    procedure EraseAllQSOs_MenuItemClick(Sender: TObject);
    procedure EraseQSO_MenuItemClick(Sender: TObject);
    procedure Erase_All_ButtonClick(Sender: TObject);
    procedure Erase_QSO_ButtonClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure Help_ButtonClick(Sender: TObject);
    procedure Language_ButtonClick(Sender: TObject);
    procedure Main_Form_OnCreate(Sender: TObject);
    procedure Main_Form_OnKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Main_Form_OnShow(Sender: TObject);
    procedure Main_Form_OnWindowStateChange(Sender: TObject);
    procedure QSO_List_PopupMenu_OnPopup(Sender: TObject);
    procedure ReuseQSO_MenuItemClick(Sender: TObject);
    procedure QSO_ListString_OnClick(Sender: TObject);
    procedure Copy_Log_ButtonClick(Sender: TObject);
    procedure Reuse_Button_OnClick(Sender: TObject);
    procedure Socket_Rx_Timer_Ontimer(Sender: TObject);
    procedure Stats_Form_ButtonClick(Sender: TObject);
    procedure Worked_Zones_Form_ButtonClick(Sender: TObject);
    procedure New_Log_ButtonClick(Sender: TObject);
    procedure Load_Log_ButtonClick(Sender: TObject);
    procedure Save_Log(Sender: TObject);
    procedure Save_Backup_Log(Sender: TObject);
    procedure Update_Banner_Titles(Sender: TObject);
    procedure Save_Config_File(Sender: TObject);
    procedure Load_Config_File(Sender: TObject);
    procedure Load_Log(Sender: TObject);
//    function  StrToCardinal(const S : String) : Cardinal;
    procedure Disable_Logging(Sender: TObject);
    procedure Enable_Logging(Sender: TObject);
    procedure Save_Log_Setup(Sender: TObject);
    procedure Load_Log_Setup(Sender: TObject);
    procedure CompileStats(Sender: TObject);
    procedure Select_QSO_Party_Actions(Sender: TObject);
    procedure Select_Mode_Actions(Sender: TObject);

  private
  public
    contest_filename,
//    contest_long_filename,
    config_long_filename: String;
    Config_File_StrList: TStringList;
    Log_Config_File_StrList: TStringList;

  end;

var
  Main_Form: TMain_Form;
  qso_in_edit_flag: Boolean;
  qc_worked_zones_2d_array, on_worked_zones_2d_array: array[0..7] of array of String;
  qc_worked_Sponsor_2d_array, on_worked_Sponsor_2d_array: array[0..7] of array of String;
  language: Integer = 0;
  french_lang: Boolean = True;
  qc_cab_file_name: String;
  on_cab_file_name: String;
  dupe_found: Boolean;
  dupe_row_array: array of Integer;
  contest_long_filename: String;
  dupe_check_enabled: Boolean = True;
  row_index, row_index2,
  num_ph_qso_qc, num_cw_qso_qc, num_ph_qso_on, num_cw_qso_on, num_ph_qso_dx, num_cw_qso_dx, num_qso_total_qc, num_qso_total_on,
  num_bonus_stations_qc, num_bonus_stations_on, bonus_tot_qc, bonus_tot_on,
  mobile_bonus_Zones_qc, mobile_bonus_Zones_on,
  num_dupes_ph, num_dupes_cw, num_dupes_tot,
  num_mult_tot, qso_score_in_qcqp, qso_score_in_onqp, total_score_in_qcqp, total_score_in_onqp, num_mult_in_qcqp, num_mult_in_onqp, zone_index: Integer;
  zones_qc, zones_on, zones_dx, myZones_qc, myZones_on: Array of String;
  SoapBox_String: String;
  Keyer_Support_Timestamp_Old: LongInt = 10;
  Keyer_Support_Present: Boolean = False;
  Sock: TUDPBlockSocket;

const

VERSION_NUMBER: String = 'v0.41 2026-03-31';
   // The list of contributors is located in the lan_select unit file.

BANDS_ARRAY: array of String =    ('160m', '80m', '40m', '20m',  '15m',  '10m',   '6m',   '2m');
FREQS_ARRAY: array of String =    ('1800','3500','7000','14000','21000','28000','50000','144000');
QC_ZONES_ARRAY: array of String = ('ATE','BSA','QUE','CDQ','CAS','CND','ETE','GIM','LDE','LNS','LVL','MAU','MEE','MTL','NDQ','OTS','SLS');
ON_ZONES_ARRAY: array of String = ('ALG','BRA','BFD','BRU','CHK','COC','DUF','DUR','ELG','ESX','FRO','GRY','HAL','HLB','HTN','HAM','HAS','HUR','KAW','KEN',
                                   'LAM','LAN','LGR','LXA','MAN','MSX','MUS','NIA','NIP','NFK','NOR','OTT','OXF','PSD','PEL','PER','PET','PRU','PED','RAI',
                                   'REN','SIM','SDG','SUD','TBY','TIM','TOR','WAT','WEL','YRK');
OTHER_ZONES_ARRAY: array of String = ('DX', 'NF', 'LB', 'PE', 'NB', 'NS', 'MB', 'ON', 'SK', 'AB', 'BC', 'NT', 'YT', 'NU', 'NWT', // Canadian provinces are included (except QC)
                                      'AK', 'AL', 'AR', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA', 'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'MA', 'MD',
                                      'ME', 'MI', 'MN', 'MO', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ', 'NM', 'NV', 'NY', 'OH', 'OK', 'OR', 'PA', 'PR', 'RI', 'SC', 'SD',
                                      'TN', 'TX', 'UT', 'VA', 'VI', 'VT', 'WA', 'WI', 'WV', 'WY');

QC_SPONSOR_ARRAY: array of String = ('VE2CRO', 'VA2RAC');
ON_SPONSOR_ARRAY: array of String = ('VA3CCO','VE3CCO','VE3ODX','VA3RAC','VE3RHQ');
PH_MODES_ARRAY: array of String = ('SSB','FM');
FRENCH = 0;
ENGLISH = 1;

implementation
uses QSO_Entry, Launch_Splashscreen, Worked_Zones, Log_Setup, stats_form, qc_cab_editor, on_cab_editor, lang_select, SandBox;


{$R *.lfm}

{ TMain_Form }


procedure TMain_Form.Save_Log_Setup(Sender: TObject);
var fileStrList:TStringList;
    cfg_filename: String;
begin
  fileStrList:= TStringList.Create;  //creating the TStringList
    cfg_filename := contest_long_filename + '_cfg';
    fileStrList.Add(IntToStr(Log_Setup_Form.Party_Select_RadioGroup.ItemIndex));
    fileStrList.Add(Log_Setup_Form.Cat_OP_ComboBox.Text);
    fileStrList.Add(Log_Setup_Form.Cat_Power_ComboBox.Text);
    fileStrList.Add(Log_Setup_Form.Cat_Station_ComboBox.Text);
//    fileStrList.Add(Log_Setup_Form.Cat_Bands_ComboBox.Text);
    fileStrList.Add(Log_Setup_Form.Cat_Mode_ComboBox.Text);
//    fileStrList.Add(Log_Setup_Form.Cat_TX_ComboBox.Text);
    fileStrList.Add(Log_Setup_Form.Station_Callsign_LabeledEdit.Text);
    fileStrList.Add(Log_Setup_Form.Zone_ComboBox.Text);
    fileStrList.Add(Log_Setup_Form.Location_ComboBox.Text);
    fileStrList.Add(Log_Setup_Form.Ops_Callsign_LabeledEdit.Text);
    fileStrList.Add(Log_Setup_Form.OpName_LabeledEdit.Text);
    fileStrList.Add(Log_Setup_Form.Email_LabeledEdit.Text);
    fileStrList.Add(Log_Setup_Form.Club_LabeledEdit.Text);
    fileStrList.SaveToFile(cfg_filename);    //saving rewritted TStringList to file
    fileStrList.Free;  //freeing the TStringList !don't forget about this!
end;

procedure TMain_Form.Select_QSO_Party_Actions(Sender: TObject);
begin
  Log_Setup_Form.Zone_ComboBox.Items.Clear;
  Log_Setup_Form.Zone_ComboBox.Items.Add('---');
  if Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [0,2] then Log_Setup_Form.Zone_ComboBox.Items.AddStrings(QC_ZONES_ARRAY);  // Important to perform, otherwise a divide-by-zero error will occur
  if Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [1,2] then Log_Setup_Form.Zone_ComboBox.Items.AddStrings(ON_ZONES_ARRAY);
  Log_Setup_Form.Zone_ComboBox.ItemIndex := 0;
  Log_Setup_Form.Zone_ComboBox.Enabled := True;
  Log_Setup_Form.Location_ComboBox.ItemIndex := 0;
  Log_Setup_Form.Location_ComboBox.Enabled := True;
  QSO_Entry_Form.Band_Entry_ListBox_1.Items.Clear;
  if Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 0 then
  begin
    QSO_Entry_Form.Band_Entry_ListBox_1.Items.AddStrings(FREQS_ARRAY[1..3]);
    Worked_Zones_Form.QC_Title_Panel.Visible := True;
    Worked_Zones_Form.ON_Title_Panel.Visible := False;
    Worked_Zones_Form.QC_Title_Panel.Align := alClient;
    Worked_Zones_Form.Band_Listboxes_QC_Panel.Visible := True;
    Worked_Zones_Form.Band_Listboxes_ON_Panel.Visible := False;
    Worked_Zones_Form.Band_Listboxes_QC_Panel.Align := alClient;
  end
  else if Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 1 then
  begin
    QSO_Entry_Form.Band_Entry_ListBox_1.Items.AddStrings(FREQS_ARRAY[0..3]);
    Worked_Zones_Form.QC_Title_Panel.Visible := False;
    Worked_Zones_Form.ON_Title_Panel.Visible := True;
    Worked_Zones_Form.ON_Title_Panel.Align := alClient;
    Worked_Zones_Form.Band_Listboxes_QC_Panel.Visible := False;
    Worked_Zones_Form.Band_Listboxes_ON_Panel.Visible := True;
    Worked_Zones_Form.Band_Listboxes_ON_Panel.Align := alClient;
  end
  else begin
    QSO_Entry_Form.Band_Entry_ListBox_1.Items.AddStrings(FREQS_ARRAY[0..3]);
    Worked_Zones_Form.QC_Title_Panel.Visible := True;
    Worked_Zones_Form.ON_Title_Panel.Visible := True;
    Worked_Zones_Form.QC_Title_Panel.Align := alTop;
    Worked_Zones_Form.ON_Title_Panel.Align := alClient;
    Worked_Zones_Form.Band_Listboxes_QC_Panel.Visible := True;
    Worked_Zones_Form.Band_Listboxes_ON_Panel.Visible := True;
    Worked_Zones_Form.Band_Listboxes_QC_Panel.Align := alTop;
    Worked_Zones_Form.Band_Listboxes_ON_Panel.Align := alClient;
    Worked_Zones_Form.Band_Listboxes_QC_Panel.Height := Round((Worked_Zones_Form.ClientHeight - Worked_Zones_Form.Legend_Panel.Height) / 2);
    Worked_Zones_Form.Band_Listboxes_ON_Panel.Height := Worked_Zones_Form.Band_Listboxes_QC_Panel.Height;
    Worked_Zones_Form.QC_Title_Panel.Height := Round(Worked_Zones_Form.Title_Panel.Height / 2) + 1;
    Worked_Zones_Form.ON_Title_Panel.Height := Round(Worked_Zones_Form.Title_Panel.Height / 2) + 1;
  end;
  QSO_Entry_Form.Band_Entry_ListBox_1.ItemIndex := 1;
end;

procedure TMain_Form.Select_Mode_Actions(Sender: TObject);
begin
  QSO_Entry_Form.Mode_Entry_ListBox.Items.Clear;
  Case (Log_Setup_Form.Cat_Mode_ComboBox.ItemIndex) of
      0: begin
              QSO_Entry_Form.Mode_Entry_ListBox.Items.Add('CW');
         end;
      1: begin
              QSO_Entry_Form.Mode_Entry_ListBox.Items.Add('SSB');
              QSO_Entry_Form.Mode_Entry_ListBox.Items.Add('FM');
         end;
      2: begin
              QSO_Entry_Form.Mode_Entry_ListBox.Items.Add('CW');
              QSO_Entry_Form.Mode_Entry_ListBox.Items.Add('SSB');
              QSO_Entry_Form.Mode_Entry_ListBox.Items.Add('FM');
         end;
  end;
  QSO_Entry_Form.Mode_Entry_ListBox.ItemIndex := 0;
  if (QSO_Entry_Form.Mode_Entry_ListBox.items[QSO_Entry_Form.Mode_Entry_ListBox.ItemIndex] = 'CW') then QSO_Entry_Form.Report_Entry_Edit.Text := '599' else QSO_Entry_Form.Report_Entry_Edit.Text := '59';
end;

procedure TMain_Form.Load_Log_Setup(Sender: TObject);
var fileStrList:TStringList;
    i: Integer;
begin
  fileStrList:= TStringList.Create;  //creating the TStringList
  fileStrList.LoadFromFile(config_long_filename);  //Loading file into TStringList
  Log_Setup_Form.Party_Select_RadioGroup.ItemIndex := StrToInt(fileStrList[0]);
  Select_QSO_Party_Actions(Nil);
  Log_Setup_Form.Cat_OP_ComboBox.Text := fileStrList[1];
  Log_Setup_Form.Cat_Power_ComboBox.Text := fileStrList[2];
  Log_Setup_Form.Cat_Station_ComboBox.Text := fileStrList[3];
//  Log_Setup_Form.Cat_Bands_ComboBox.Text := fileStrList[4];
  Log_Setup_Form.Cat_Mode_ComboBox.Text := fileStrList[4];
  Select_Mode_Actions(Nil);
//  Log_Setup_Form.Cat_TX_ComboBox.Text := fileStrList[6];
  Log_Setup_Form.Station_Callsign_LabeledEdit.Text := fileStrList[5];
  Log_Setup_Form.Zone_ComboBox.Text := fileStrList[6];
  Log_Setup_Form.Location_ComboBox.Text := fileStrList[7];
  Log_Setup_Form.Ops_Callsign_LabeledEdit.Text := fileStrList[8];
  Log_Setup_Form.OpName_LabeledEdit.Text := fileStrList[9];
  Log_Setup_Form.Email_LabeledEdit.Text := fileStrList[10];
  Log_Setup_Form.Club_LabeledEdit.Text := fileStrList[11];
  fileStrList.Free;  //freeing the TStringList !don't forget about this!
end;

//procedure TMain_Form.CompileStats(Sender: TObject);
//begin
//
//end;

procedure TMain_Form.Save_Log(Sender: TObject);   // Save the QSO list in the logfile
begin
     Save_Backup_Log(Nil);
     QSO_List_StringGrid.SaveToCSVFile(contest_long_filename, ',', false, false);
end;

procedure TMain_Form.Save_Backup_Log(Sender: TObject);   // Save the QSO list in the backup logfile
var temp_filename: String;
begin
     temp_filename := contest_long_filename + '_bak';
     CopyFile(contest_long_filename, temp_filename);
     temp_filename := config_long_filename + '_bak';
     CopyFile(config_long_filename, temp_filename);
end;

procedure TMain_Form.Update_Banner_Titles(Sender: TObject);
var
  filename_parse_array: Array of String;
begin
     filename_parse_array := SplitString(ExtractFileName(contest_long_filename),'.');
     if Length(filename_parse_array) > 1 then contest_filename := filename_parse_array[Length(filename_parse_array) - 2]
     else contest_filename := filename_parse_array[0];
     Main_Form.Caption := sMain_Form_Caption[language] + contest_filename;
     QSO_Entry_Form.Caption := sQSO_Entry_Form_Caption[language] + contest_filename;
end;

procedure TMain_Form.Load_Log(Sender: TObject);
var F: File Of byte;
  has_content: Boolean = False;
begin
  config_long_filename := contest_long_filename + '_cfg';
  if FileExists(config_long_filename) then
  begin
    Load_Log_Setup(Nil);
    if (QSO_List_StringGrid.RowCount > 1) then
    begin
      repeat QSO_List_StringGrid.DeleteRow(1) until QSO_List_StringGrid.RowCount = 1;       // Empty QSO list
    end;
    AssignFile(F, contest_long_filename);
    Reset(F);
    if FileSize(F) > 0 then has_content := True;
    CloseFile(F);
    if (has_content) then QSO_List_StringGrid.LoadFromCSVFile(contest_long_filename, ',', false, 0, false); // This manages the LoadFromCSVFile bug that erase the fixed header titles when the file is empty.
    Update_Banner_Titles(Nil);
    Worked_Zones_Form.Update_Zone_ListBoxes(Nil);
    Enable_Logging(Nil);
  end
  else begin
    Application.MessageBox(PChar(IfThen(french_lang,'Échec de chargement. Le fichier de configuration du Log est manquant.', 'Loading failure. The configuration file is missing')), PChar(IfThen(french_lang, 'Erreur de chargement', 'Loading failure')), $00000010);
    contest_long_filename := '';
    config_long_filename := '';
    Update_Banner_Titles(Nil);
    Disable_Logging(Nil);
  end;
end;

procedure TMain_Form.Load_Log_ButtonClick(Sender: TObject);
begin
  Log_Load_OpenDialog.Title := sLog_Load_OpenDialogTitle[language];
  if (Log_Load_OpenDialog.Execute) then
  begin
    if fileExists(Log_Load_OpenDialog.Filename) then
    begin
      try
         contest_long_filename := Log_Load_OpenDialog.Filename;
         Load_Log(Nil);
      except
         Application.MessageBox(PChar(IfThen(french_lang,'Echec de chargement. Le fichier Log n''a pas le bon format ou est corrompu.', 'Loading failure. The log file has the wrong format or is corrupted')), PChar(IfThen(french_lang, 'Erreur de chargement', 'Loading failure')), $00000010);
      end;
    end;
  end;
end;

procedure TMain_Form.New_Log_ButtonClick(Sender: TObject);
var
  file_id: longint;
  i: Integer;
begin
     Log_Create_SaveDialog.Title := sLog_Create_SaveDialogTitle[language];
     if Log_Create_SaveDialog.Execute then
     begin
          Log_Setup_Form.Party_Select_RadioGroup.Enabled := True;  // Re-enable choice of contest.
          Log_Setup_Form.Party_Select_RadioGroup.ItemIndex := 0;   // QCQP by default
          Log_Setup_Form.Location_ComboBox.Enabled := True;        // Re-populate comboboxes with default values, otherwise a divide-by-zero error will occur
          Log_Setup_Form.Zone_ComboBox.Enabled := True;
          Select_QSO_Party_Actions(Nil);
          contest_long_filename := ChangeFileExt(Log_Create_SaveDialog.Filename, '.qplog');     // Replaces file name extension with '.qplog', or add that extension if none were provided
          config_long_filename := ChangeFileExt(contest_long_filename, '.qplog_cfg');           // Creates file name with extension '.qplog_cfg'
          file_id := FileCreate(contest_long_filename);     // creates the log file
          FileClose(file_id);
          file_id := FileCreate(config_long_filename);       // creates the log config file
          FileClose(file_id);
          if (QSO_List_StringGrid.RowCount > 1) then repeat QSO_List_StringGrid.DeleteRow(1) until QSO_List_StringGrid.RowCount = 1;       // Empty QSO list
          Update_Banner_Titles(Nil);
          Enable_Logging(Nil);
          Config_Log_ButtonClick(Nil);
          Main_Form.Enabled := False;
          QSO_Entry_Form.Enabled := False;
          Worked_Zones_Form.Enabled := False;
          Log_Setup_Form.Visible := True;
          Worked_Zones_Form.Update_Zone_ListBoxes(Nil);
     end;
end;

procedure TMain_Form.Worked_Zones_Form_ButtonClick(Sender: TObject);
begin
     Worked_Zones_Form.Visible := True;
     QSO_Entry_Form.SetFocus;
end;

procedure TMain_Form.Erase_QSO_ButtonClick(Sender: TObject);
begin
  EraseQSO_MenuItemClick(Nil);
end;

procedure TMain_Form.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
     Save_Config_File(Nil);
     Application.Terminate;
end;

procedure TMain_Form.Help_ButtonClick(Sender: TObject);
begin
  {$IFDEF MSWindows}
  if (language = FRENCH) then OpenDocument('Help\Aide.pdf')
  else if (language = ENGLISH) then OpenDocument('Help\Help.pdf');
  {$ELSE}
  if (language = FRENCH) then OpenDocument('./Help/Aide.pdf')
  else if (language = ENGLISH) then OpenDocument('./Help/Help.pdf');
  {$ENDIF}
//  OpenDocument('./Help/Aide.pdf');
end;

procedure TMain_Form.Language_ButtonClick(Sender: TObject);
begin
  if language = ENGLISH then
  begin
    language := FRENCH;
    french_lang := True;
  end else
  begin
    language := ENGLISH;
    french_lang := False;
  end;
  Lang_Select.Switch_Lang(Nil);
  Save_Config_File(Nil);
end;

procedure TMain_Form.Main_Form_OnCreate(Sender: TObject);
begin
  qso_in_edit_flag := False;
  Config_File_StrList := TStringlist.Create;
  Sock := TUDPBlockSocket.Create;
  Sock.Bind('127.0.0.1','6798');   // listen port

//      QSO_List_StringGrid.SelectedColor:= $0076C008;   // QPLog logo green
//  CW_Interface_TX_LUDPComponent.Connect;
//  CW_Interface_RX_LUDPComponent.Listen(6798);
end;

procedure TMain_Form.Main_Form_OnKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
     if (((Key = ord('e')) or (Key = ord('E'))) and (Shift = [ssCtrl])) then       // Edit highlighted QSO
     begin
       Edit_QSO_MenuItemClick(Nil);
     end;
     if (((Key = ord('r')) or (Key = ord('R'))) and (Shift = [ssCtrl])) then       // Re-use highlighted QSO
     begin
       ReuseQSO_MenuItemClick(Nil);
     end;
     if (Key in [112..123]) then        // One of F1-F12 Function keys pressed.
     begin
       QSO_Entry_Form.Send_Keyer_Command(IntToStr(Ord(Key)));
     end;
     if ((Key = 27) and (Keyer_Support_Present)) then QSO_Entry_Form.Send_Keyer_Command('27');         // Escape key pressed, send Escape code to keyer to stop CW.
     Key := 0;
end;

procedure TMain_Form.Main_Form_OnShow(Sender: TObject);
var
  warning_form : TForm;
  Message: String;
begin
     if fileExists(contest_long_filename) then
     begin
          Load_Log(Nil);
          QSO_Entry_Form.Enabled := True;
     end
     else begin
        Message :=
           PChar(IfThen(french_lang,'Vous devez d''abord créer un nouveau log ou charger un log existant.',
                                    'You must first create a new log or load an existing log.'));
        warning_form := CreateMessageDialog(Message, mtInformation, [mbOK]);
        warning_form.Position := poOwnerFormCenter;
        warning_form.ShowModal;
        Disable_Logging(Nil);
        QSO_Entry_Form.Enabled := False;
     end;
end;

procedure TMain_Form.Main_Form_OnWindowStateChange(Sender: TObject);
begin
  if (Main_Form.WindowState = wsNormal) then
  begin
       if (QSO_Entry_Form.WindowState = wsMinimized) then QSO_Entry_Form.WindowState := wsNormal;
  end;
end;

procedure TMain_Form.QSO_List_PopupMenu_OnPopup(Sender: TObject);
begin
     if ((QSO_List_StringGrid.RowCount > 1) and (contest_long_filename <> '')) then
     begin
          ReuseQSO_MenuItem.Enabled := True;
          Edit_QSO_MenuItem.Enabled := True;
          EraseQSO_MenuItem.Enabled := True;
          EraseAllQSOs_MenuItem.Enabled := True;
    end else
    begin
         ReuseQSO_MenuItem.Enabled := False;
         Edit_QSO_MenuItem.Enabled := False;
         EraseQSO_MenuItem.Enabled := False;
         EraseAllQSOs_MenuItem.Enabled := False;
    end;

end;

procedure TMain_Form.ReuseQSO_MenuItemClick(Sender: TObject);
begin
     if (QSO_List_StringGrid.RowCount > 1) then
     begin
       dupe_check_enabled := False;
       QSO_Entry_Form.Date_Entry_Edit.Text := SplitString(QSO_List_StringGrid.Cells[0,QSO_List_StringGrid.Row],'_')[0];
       QSO_Entry_Form.Time_Entry_Edit.Text := SplitString(QSO_List_StringGrid.Cells[0,QSO_List_StringGrid.Row],'_')[1];
       QSO_Entry_Form.Callsign_Entry_Edit.Text := QSO_List_StringGrid.Cells[3,QSO_List_StringGrid.Row];
       QSO_Entry_Form.Report_Entry_Edit.Text := QSO_List_StringGrid.Cells[4,QSO_List_StringGrid.Row];
       QSO_Entry_Form.Zone_Entry_Edit.Text := QSO_List_StringGrid.Cells[5,QSO_List_StringGrid.Row];
       QSO_Entry_Form.Mode_Entry_ListBox.ItemIndex := QSO_Entry_Form.Mode_Entry_ListBox.Items.IndexOf(QSO_List_StringGrid.Cells[2,QSO_List_StringGrid.Row]);
       QSO_Entry_Form.Band_Entry_ListBox_1.ItemIndex := QSO_Entry_Form.Band_Entry_ListBox_1.Items.IndexOf(QSO_List_StringGrid.Cells[1,QSO_List_StringGrid.Row]);
       QSO_Entry_Form.Band_Entry_ListBox_2.ItemIndex := QSO_Entry_Form.Band_Entry_ListBox_2.Items.IndexOf(QSO_List_StringGrid.Cells[1,QSO_List_StringGrid.Row]);
       dupe_check_enabled := True;
       QSO_Entry_Form.SetFocus;
     end;
end;

// This function recalls the QSO into the QSO entry window so that another QSO with the same station can be quickly logged.
procedure TMain_Form.QSO_ListString_OnClick(Sender: TObject);
begin
end;

procedure TMain_Form.Erase_All_ButtonClick(Sender: TObject);
begin
  EraseAllQSOs_MenuItemClick(Nil);
end;

procedure TMain_Form.Edit_QSO_ButtonClick(Sender: TObject);
begin
  Edit_QSO_MenuItemClick(Nil);
end;

procedure TMain_Form.EraseQSO_MenuItemClick(Sender: TObject);
begin
  if (QSO_List_StringGrid.RowCount > 1) then
  begin
    Save_Backup_Log(Nil);
    QSO_List_StringGrid.DeleteRow(QSO_List_StringGrid.Row);
    Save_Log(Nil);
    QSO_Entry_Form.SetFocus;
  end;
end;

procedure TMain_Form.Edit_QSO_MenuItemClick(Sender: TObject);
begin
  if (QSO_List_StringGrid.Row > 0) then           // A line is selected, proceed with editing
  begin
     qso_in_edit_flag:= True;
     QSO_Entry_Form.QSO_Edit_Label.Caption := sQSO_QSO_Edit_Label[language];
     QSO_Entry_Form.Date_Time_Refresh_Timer.Enabled := false;    // Stop tme and date update timer
     Main_Form.Enabled := False;
     QSO_Entry_Form.Enabled := True;
     QSO_Entry_Form.Time_Entry_Edit.Enabled := True;
     QSO_Entry_Form.Date_Entry_Edit.Enabled := True;
     QSO_Entry_Form.Save_Entry_Button.Caption := sModify_Entry_Button[language];
     QSO_Entry_Form.Cancel_Entry_Button.Caption := sModify_Cancel_Entry_Button[language];
     QSO_Entry_Form.QSO_Edit_Label.Color := clYellow;
     QSO_Entry_Form.Date_Entry_Edit.Text := SplitString(QSO_List_StringGrid.Cells[0,QSO_List_StringGrid.Row],'_')[0];
     QSO_Entry_Form.Time_Entry_Edit.Text := SplitString(QSO_List_StringGrid.Cells[0,QSO_List_StringGrid.Row],'_')[1];
     QSO_Entry_Form.Callsign_Entry_Edit.Text := QSO_List_StringGrid.Cells[3,QSO_List_StringGrid.Row];
     QSO_Entry_Form.Report_Entry_Edit.Text := QSO_List_StringGrid.Cells[4,QSO_List_StringGrid.Row];
     QSO_Entry_Form.Zone_Entry_Edit.Text := QSO_List_StringGrid.Cells[5,QSO_List_StringGrid.Row];
     QSO_Entry_Form.Mode_Entry_ListBox.ItemIndex := QSO_Entry_Form.Mode_Entry_ListBox.Items.IndexOf(QSO_List_StringGrid.Cells[2,QSO_List_StringGrid.Row]);
     QSO_Entry_Form.Band_Entry_ListBox_1.ItemIndex := QSO_Entry_Form.Band_Entry_ListBox_1.Items.IndexOf(QSO_List_StringGrid.Cells[1,QSO_List_StringGrid.Row]);
     QSO_Entry_Form.Band_Entry_ListBox_2.ItemIndex := QSO_Entry_Form.Band_Entry_ListBox_2.Items.IndexOf(QSO_List_StringGrid.Cells[1,QSO_List_StringGrid.Row]);
  end;
  QSO_Entry_Form.SetFocus;
end;

procedure TMain_Form.EraseAllQSOs_MenuItemClick(Sender: TObject);
begin
     if ((QSO_List_StringGrid.RowCount > 1) and (MessageDlg('Question', IfThen(french_lang,'Voulez vous vraiment effacer tous les QSOs?','Do you wish to Erase All QSOs?'), mtConfirmation, [mbNo, mbYes],0, mbNo) = mrYes)) then
     begin
          Save_Backup_Log(Nil);
          repeat QSO_List_StringGrid.DeleteRow(1) until QSO_List_StringGrid.RowCount = 1;       // Empty QSO list
          Save_Log(Nil);
          QSO_Entry_Form.SetFocus;
     end;
end;

procedure TMain_Form.About_ButtonClick(Sender: TObject);
begin
  Launch_Splash_Form.Show;
  Main_Form.Enabled := False;
  if not (QSO_Entry_Form = nil) then QSO_Entry_Form.Enabled := False;
  if not (Worked_Zones_Form = nil) then Worked_Zones_Form.Enabled := False;
  if not (Statistics_Form = nil) then Statistics_Form.Enabled := False;
  Launch_Splash_Form.SetFocus;
end;

procedure TMain_Form.Cabrillo_ButtonClick(Sender: TObject);
var
  F: TextFile;
  party: Integer;
  qc_cab: Boolean = False;
  on_cab: Boolean = False;
  cab_file_name: String;
  ldatetime: array of string;
  slash_char: String;
  warning_form : TForm;
  Message: String;
  location_str: String;
  str_index: Integer;
  StartPos, SpacePos: Integer;
  SubStr: string;


begin
   {$IFDEF MSWindows}
   slash_char := '\';
   {$ELSE}
   slash_char := '/';
   {$ENDIF}
     qc_cab_file_name := '';
     on_cab_file_name := '';
     if ((contest_long_filename <> '') and (MessageDlg(PChar(IfThen(french_lang, 'La génération de fichier Cabrillo risque de ré-écrire un fichier Cabrillo existant. Voulez-vous continuer?',
                                                                                 'The Cabrillo file generation may overwrite previously generated Cabrillo files. Do you want to proceed?')), mtConfirmation, [mbYes, mbNo],1) = mrYes)) then
     begin
       for party:= 0 to 1 do            // 0: QC, 1: ON
       begin
          if (party = 0) and (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [0,2]) then qc_cab := True
          else if (party = 1) and (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [1,2]) then on_cab := True;
          if qc_cab then
          begin
            cab_file_name := GetCurrentDir + slash_char + Log_Setup_Form.Station_Callsign_LabeledEdit.Text + '_QCQP_' + ReplaceStr(DateTimeToStr(Date),'/','-') + '.cablog';
            qc_cab_file_name := cab_file_name;
          end;
          if on_cab then
          begin
            cab_file_name := GetCurrentDir + slash_char + Log_Setup_Form.Station_Callsign_LabeledEdit.Text + '_ONQP_' + ReplaceStr(DateTimeToStr(Date),'/','-') + '.cablog';
            on_cab_file_name := cab_file_name;
          end;
          if (((party = 0) and (qc_cab = true)) or ((party = 1) and (on_cab = true))) then
          begin
            AssignFile(F, cab_file_name);
            Rewrite(F);
            WriteLn(F, 'START-OF-LOG: 3.0');
            WriteLn(F, 'CREATED-BY: QPLog - QSO PARTY LOGGER, ' + VERSION_NUMBER + ', HTTPS://VE2ZAZ.NET');
            if qc_cab then WriteLn(F, 'CONTEST: QC-QSO-PARTY');
            if on_cab then WriteLn(F, 'CONTEST: ON-QSO-PARTY');
            WriteLn(F, 'SUBMIT-LOG-FR: https://qcqp.contesting.com/qcqpsubmitlog.php?lang=fr');
            WriteLn(F, 'SUBMIT-LOG-EN: https://qcqp.contesting.com/qcqpsubmitlog.php?lang=en');
            WriteLn(F, 'CATEGORY-OPERATOR: ' + Log_Setup_Form.Cat_OP_ComboBox.Text);
            WriteLn(F, 'CATEGORY-POWER: ' + Log_Setup_Form.Cat_Power_ComboBox.Text);
            WriteLn(F, 'CATEGORY-STATION: ' + Log_Setup_Form.Cat_Station_ComboBox.Text);
            WriteLn(F, 'CATEGORY-BAND: ALL');
  //          DebugLn(F, 'CATEGORY-BAND: ' + Log_Setup_Form.Cat_Bands_ComboBox.Text);
            case (Log_Setup_Form.Cat_Mode_ComboBox.ItemIndex) of
                0: WriteLn(F, 'CATEGORY-MODE: CW');
                1: WriteLn(F, 'CATEGORY-MODE: SSB');        // This includes FM
                2: WriteLn(F, 'CATEGORY-MODE: SSB+CW');
            end;
  //          DebugLn(F, 'CATEGORY-TRANSMITTER: ' + Log_Setup_Form.Cat_TX_ComboBox.Text);
            WriteLn(F, 'CALLSIGN: ' + Log_Setup_Form.Station_Callsign_LabeledEdit.Text);
            if (Log_Setup_Form.Location_ComboBox.Text <> '---') then location_str := Log_Setup_Form.Location_ComboBox.Text
            else if  Log_Setup_Form.Zone_ComboBox.Text in QC_ZONES_ARRAY then location_str := 'QC'
            else if  Log_Setup_Form.Zone_ComboBox.Text in ON_ZONES_ARRAY then location_str := 'ON'
            else location_str := '';    //  Catches any possible mistake or problem
            WriteLn(F, 'LOCATION: ' + location_str);
            if (Length(Log_Setup_Form.Ops_Callsign_LabeledEdit.Text) > 0) then WriteLn(F, 'OPERATORS: ' + Log_Setup_Form.Ops_Callsign_LabeledEdit.Text);
            if (Length(Log_Setup_Form.Club_LabeledEdit.Text) > 0) then WriteLn(F, 'CLUB: ' + Log_Setup_Form.Club_LabeledEdit.Text);
            WriteLn(F, 'NAME: ' + Log_Setup_Form.OpName_LabeledEdit.Text);
            WriteLn(F, 'EMAIL: ' + Log_Setup_Form.Email_LabeledEdit.Text);
            if qc_cab then WriteLn(F, 'CLAIMED-SCORE: ' + IntToStr(total_score_in_qcqp))
            else if on_cab then WriteLn(F, 'CLAIMED-SCORE: ' + IntToStr(total_score_in_onqp));
            // Soapbox comments capture here
            SoapBox_Form.SoapBox_Memo.Lines.Clear;
            SoapBox_Form.SoapBox_Memo.Font.Color := clInactiveCaption;
            if qc_cab then
            begin
              SoapBox_Form.SoapBox_Memo.Lines.Add('SOAPBOX - Québec-QSO-PARTY');
              SoapBox_Form.Caption := 'SOAPBOX - Québec-QSO-PARTY';
              SoapBox_Form.SoapBox_Memo.Lines.Add(sSoapBox_Form_SoapBox_Memo_Lines_Text[language]);
              SoapBox_Form.ShowModal;  // Execution pauses here until window is closed.
            end;
            if on_cab then
            begin
              SoapBox_Form.SoapBox_Memo.Lines.Add('SOAPBOX - Ontario-QSO-PARTY');
              SoapBox_Form.Caption := 'SOAPBOX - Ontario-QSO-PARTY';
              SoapBox_Form.SoapBox_Memo.Lines.Add(sSoapBox_Form_SoapBox_Memo_Lines_Text[language]);
              SoapBox_Form.ShowModal;  // Execution pauses here until window is closed.
            end;
  //          SoapBox_Form.SoapBox_Memo.Lines.Add(sSoapBox_Form_SoapBox_Memo_Lines_Text[language]);
  //          SoapBox_Form.ShowModal;  // Execution pauses here until window is closed.
            if (SoapBox_Form.SoapBox_Memo.Font.Color = clInactiveCaption) then SoapBox_String := ''
            else  SoapBox_String := SoapBox_Form.SoapBox_Memo.Lines.text;
            // Loop to split the entire input string into chunks of 70 characters maximum.
            StartPos := 1;
            while StartPos <= Length(SoapBox_String) do
            begin
              // Find the first space after the max length limit
              if (StartPos + 70 - 1 <= Length(SoapBox_String)) then
              begin
                SpacePos := StartPos + 70 - 1;
                // Ensure we split at the last space within the limit
                while (SpacePos > StartPos) and (SoapBox_String[SpacePos] <> ' ') do
                  Dec(SpacePos);
              end
              else
                SpacePos := Length(SoapBox_String); // If not enough characters, take the remaining string
              // Extract the substring and print it
              SubStr := Copy(SoapBox_String, StartPos, SpacePos - StartPos + 1);
              WriteLn(F, 'SOAPBOX: ' + SubStr);
              // Update the starting position for the next substring
              StartPos := SpacePos + 1;
              // Skip over leading spaces (if any) after the split
              while (StartPos <= Length(SoapBox_String)) and (SoapBox_String[StartPos] = ' ') do
                Inc(StartPos);
            end;
            // Process list of QSOs
            for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
            begin
                  ldatetime := SplitString(QSO_List_StringGrid.Cells[0,row_index],'_');
                  write(F, 'QSO: ');
                  if (QSO_List_StringGrid.Cells[1,row_index] = '50000') then write(F, '50' + ' ')     // freq
                  else if (QSO_List_StringGrid.Cells[1,row_index] = '144000') then write(F, '144' + ' ')
                  else write(F, QSO_List_StringGrid.Cells[1,row_index] + ' ');     // freq
                  if QSO_List_StringGrid.Cells[2,row_index] = 'SSB' then write(F, 'PH ')      // Mode
                  else write(F, QSO_List_StringGrid.Cells[2,row_index] + ' ');
                  write(F, ldatetime[0] + ' ');      // Date
                  delete(ldatetime[1],3,1);        // Removes the ':' character
                  write(F, ldatetime[1] + ' ');      // Time.
                  write(F, Log_Setup_Form.Station_Callsign_LabeledEdit.Text + ' ');     // My Callsign
                  if QSO_List_StringGrid.Cells[2,row_index] = 'CW' then write(F, '599 ') else write(F, '59 ');// My sig report, always 59 or 599
                  if (qc_cab and (QSO_List_StringGrid.Cells[6,row_index] = 'QC')) then
                  begin
                       if (QSO_List_StringGrid.Cells[7,row_index] in QC_ZONES_ARRAY) then write(F, QSO_List_StringGrid.Cells[7,row_index] + ' ')     // His zone
                       else if (QSO_List_StringGrid.Cells[7,row_index] in ON_ZONES_ARRAY) then write(F, 'ON ')
                       else write(F, QSO_List_StringGrid.Cells[7,row_index] + ' ');
                  end
                  else if (on_cab and (QSO_List_StringGrid.Cells[6,row_index] = 'ON')) then
                  begin
                       if (QSO_List_StringGrid.Cells[7,row_index] in ON_ZONES_ARRAY) then write(F, QSO_List_StringGrid.Cells[7,row_index] + ' ')     // His zone
                       else if (QSO_List_StringGrid.Cells[7,row_index] in QC_ZONES_ARRAY) then write(F, 'QC ')
                       else write(F, QSO_List_StringGrid.Cells[7,row_index] + ' ');
                  end
                  else write(F, QSO_List_StringGrid.Cells[7,row_index] + ' ');     // His zone. Covers both qc_cab and on_cab
                  write(F, QSO_List_StringGrid.Cells[3,row_index] + ' ');     // His Callsign
                  write(F, QSO_List_StringGrid.Cells[4,row_index] + ' ');     // Signal report
                  WriteLn(F, QSO_List_StringGrid.Cells[5,row_index] + ' ');     // His zone
            end;
            WriteLn(F, 'END-OF-LOG:');
            CloseFile(F);
          end;
          qc_cab := False;
          on_cab := False;
       end;
       ShowMessage(PChar(IfThen(french_lang,'Le ou les fichiers Cabrillo on été générés et sauvegardés avec succès. Ils portent les noms montrés ci-bas. '
         + 'Le contenu Cabrillo sera affiché dans un éditeur après avoir fermé cette fenêtre. Veuillez le réviser au besoin pour qu''il soit conforme au format et contenu attendus. N''oubliez pas de sauvegarder les changements. '
         + 'Si aucun changement n''est requis, vous pouvez simplement fermer la fenêtre d''édition.'
         + sLineBreak + ' ' + sLineBreak
         + 'VOUS ÊTES RESPONABLE DU CONTENU DES FICHIERS CABRILLO.'
         + sLineBreak + ' ' + sLineBreak
         + qc_cab_file_name + sLineBreak + sLineBreak
         + on_cab_file_name + sLineBreak + sLineBreak,
           'The Cabrillo file(s) were successfully generated and saved. They bear the file name(s) shown below. '
         + 'The Cabrillo content will be displayed in an editor after this window is closed. Please revise it as necessary to conform to the expected format and content. Do not forget to save the changes. '
         + 'If no changes are required, you can simply close the editor window.'
         + sLineBreak + ' ' + sLineBreak
         + 'YOU ARE RESPONSIBLE FOR THE CABRILLO FILE CONTENT.'
         + sLineBreak + ' ' + sLineBreak
         + qc_cab_file_name + sLineBreak + sLineBreak
         + on_cab_file_name + sLineBreak + sLineBreak)));
        if (qc_cab_file_name <> '') then
        begin
             QC_Cab_Edit_Form.visible := True;
             QC_Cab_Edit_Form.SetFocus;
             QC_Cab_Edit_Form.QC_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Modified := False;
        end;
        if (on_cab_file_name <> '') then
        begin
             ON_Cab_Edit_Form.visible := True;
             ON_Cab_Edit_Form.SetFocus;
             ON_Cab_Edit_Form.ON_Cabrillo_File_Editor_Frame.Cab_Edit_Form_Memo.Modified := False;
       end;
     end;
end;

procedure TMain_Form.Config_Log_ButtonClick(Sender: TObject);
begin
     if (contest_long_filename <> '') then
     begin
       Main_Form.Enabled := False;
       QSO_Entry_Form.Enabled := False;
       Worked_Zones_Form.Enabled := False;
       Log_Setup_Form.Visible := True;
     end;
end;

procedure TMain_Form.Copy_Log_ButtonClick(Sender: TObject);
var old_contest_long_filename, old_config_filename: string;
begin
     if (contest_long_filename <> '') then
     begin
       old_contest_long_filename := contest_long_filename;
       old_config_filename := config_long_filename;

       Log_Rename_SaveDialog.FileName := contest_long_filename;
       Log_Rename_SaveDialog.Title := sLog_Rename_SaveDialog[language];
        if Log_Rename_SaveDialog.Execute then
        begin
             if (Log_Rename_SaveDialog.Filename = contest_long_filename) then
                Application.MessageBox(PChar(IfThen(french_lang,'Echec de copie de log. Le nouveau nom de log est identique à l''ancien.',
                'Copy error. The new log name is identical to the old one')), PChar(IfThen(french_lang, 'Erreur de copie','Copy error')), $00000010)
             else begin
                 contest_long_filename := Log_Rename_SaveDialog.Filename;
                 If CopyFile(old_contest_long_filename, contest_long_filename) then
                 begin
                      Update_Banner_Titles(Nil);
                      Save_Backup_Log(Nil);
                      config_long_filename := Log_Rename_SaveDialog.Filename + '_cfg';
                      CopyFile(old_config_filename, config_long_filename);
                 end;
             end;
        end;
     end;
end;

procedure TMain_Form.Reuse_Button_OnClick(Sender: TObject);
begin
     ReuseQSO_MenuItemClick(Nil);
end;

procedure TMain_Form.Socket_Rx_Timer_Ontimer(Sender: TObject);
var
    Rx_Str: String;
    Temp: LongInt;
begin
  While Sock.CanRead(0) do Rx_Str := Sock.RecvPacket(0);
//  DebugLn('Rx_Str: ' + Rx_Str);
  if (TryStrToInt(Rx_Str,Temp)) then
  begin
      DebugLn('Keyer_Support_Timestamp Received: ' + IntToStr(Temp));
      if ((DateTimeToUnix(Now) - Temp) <= 2) then
      begin
        Keyer_Support_Present := True;
        Keyer_Support_Timestamp_Old  := Temp;
      end;
  end
  else if ((DateTimeToUnix(Now) - Keyer_Support_Timestamp_Old) > 2) then  Keyer_Support_Present := False;
end;

procedure TMain_Form.Stats_Form_ButtonClick(Sender: TObject);
begin
     Statistics_Form.Visible:= True;
end;

procedure TMain_Form.Save_Config_File(Sender: TObject);
begin
  Config_File_StrList[0] := IntToStr(Main_Form.Left);
  Config_File_StrList[1] := IntToStr(Main_Form.Top);
  Config_File_StrList[2] := IntToStr(Main_Form.Width);
  Config_File_StrList[3] := IntToStr(Main_Form.Height);
  Config_File_StrList[4] := IntToStr(QSO_Entry_Form.Left);
  Config_File_StrList[5] := IntToStr(QSO_Entry_Form.Top);
  Config_File_StrList[6] := IntToStr(QSO_Entry_Form.Width);
  Config_File_StrList[7] := IntToStr(QSO_Entry_Form.Height);
  Config_File_StrList[8] := IntToStr(Worked_Zones_Form.Left);
  Config_File_StrList[9] := IntToStr(Worked_Zones_Form.Top);
  Config_File_StrList[10] := IntToStr(Worked_Zones_Form.Width);
  Config_File_StrList[11] := IntToStr(Worked_Zones_Form.Height);
  Config_File_StrList[12] := IntToStr(Statistics_Form.Left);
  Config_File_StrList[13] := IntToStr(Statistics_Form.Top);
//  Config_File_StrList[14] := IntToStr(Statistics_Form.Width);
//  Config_File_StrList[15] := IntToStr(Statistics_Form.Height);
  Config_File_StrList[16] := IntToStr(language);
  Config_File_StrList[17] := contest_long_filename;
  Config_File_StrList[18] := BoolToStr(Statistics_Form.Visible);
  Config_File_StrList[19] := BoolToStr(Worked_Zones_Form.Visible);
  Config_File_StrList.SaveToFile('Session.cfg');
end;

// Function called in .lpr project file at launch, after all forms are available
procedure TMain_Form.Load_Config_File(Sender: TObject);
var i: integer;
begin
    Disable_Logging(Nil);
    if FileExists('Session.cfg') then
    begin
      Config_File_StrList.LoadFromFile('Session.cfg');  //Loading file into TStringList
      Main_Form.Left := StrToInt(Config_File_StrList[0]);
      Main_Form.Top := StrToInt(Config_File_StrList[1]);
      Main_Form.Width := StrToInt(Config_File_StrList[2]);
      Main_Form.Height := StrToInt(Config_File_StrList[3]);
      QSO_Entry_Form.Left := StrToInt(Config_File_StrList[4]);
      QSO_Entry_Form.Top := StrToInt(Config_File_StrList[5]);
      QSO_Entry_Form.Width := StrToInt(Config_File_StrList[6]);
      QSO_Entry_Form.Height := StrToInt(Config_File_StrList[7]);
      Worked_Zones_Form.Left := StrToInt(Config_File_StrList[8]);
      Worked_Zones_Form.Top := StrToInt(Config_File_StrList[9]);
      Worked_Zones_Form.Width := StrToInt(Config_File_StrList[10]);
      Worked_Zones_Form.Height := StrToInt(Config_File_StrList[11]);
      Statistics_Form.Left := StrToInt(Config_File_StrList[12]);
      Statistics_Form.Top := StrToInt(Config_File_StrList[13]);
//      Statistics_Form.Width := StrToInt(Config_File_StrList[14]);
//      Statistics_Form.Height := StrToInt(Config_File_StrList[15]);
      language := StrToInt(Config_File_StrList[16]);
      if (language = FRENCH) then french_lang := True else french_lang := False;
      contest_long_filename := Config_File_StrList[17];
      Statistics_Form.Visible := StrToBool(Config_File_StrList[18]);
      Worked_Zones_Form.Visible := StrToBool(Config_File_StrList[19]);
      Lang_Select.Switch_Lang(Nil);
    end
    else begin
         for i := 0 to 39 do Config_File_StrList.Add('');  // Create an empty stringlist.
    end;
end;

procedure TMain_Form.Enable_Logging(Sender: TObject);
begin
     QSO_Entry_Form.Enabled := True;
     Edit_QSO_Button.Enabled := True;
     Erase_QSO_Button.Enabled := True;
     Worked_Zones_Button.Enabled := True;
     Erase_All_Button.Enabled := True;
     Stats_Button.Enabled := True;
     Cabrillo_Button.Enabled := True;
     Copy_Log_Button.Enabled := True;
     Config_Log_Button.Enabled := True;
     Reuse_Button.Enabled := True;
     ReuseQSO_MenuItem.Enabled := True;
     Edit_QSO_MenuItem.Enabled := True;
     EraseQSO_MenuItem.Enabled := True;
     EraseAllQSOs_MenuItem.Enabled := True;
end;

procedure TMain_Form.Disable_Logging(Sender: TObject);
begin
     QSO_Entry_Form.Enabled := False;
     Edit_QSO_Button.Enabled := False;
     Erase_QSO_Button.Enabled := False;
     Worked_Zones_Button.Enabled := False;
     Erase_All_Button.Enabled := False;
     Stats_Button.Enabled := False;
     Cabrillo_Button.Enabled := False;
     Copy_Log_Button.Enabled := False;
     Config_Log_Button.Enabled := False;
     Reuse_Button.Enabled := False;
     ReuseQSO_MenuItem.Enabled := False;
     Edit_QSO_MenuItem.Enabled := False;
     EraseQSO_MenuItem.Enabled := False;
     EraseAllQSOs_MenuItem.Enabled := False;
end;

function ArrayIndex(arr: array of String; str_element: String): Integer;
var
  i: Integer;
begin
  Result := -1;
  for i := Low(arr) to High(arr) do
    if (arr[i] = str_element) then Result := i;
end;

function IsNumberInArray(arr: array of Integer; num: Integer): Boolean;
var
  i: Integer;
begin
  Result := False;  // Default to not found
  for i := Low(arr) to High(arr) do
  begin
    if arr[i] = num then
    begin
      Result := True;  // Number found
      Exit;  // Exit the loop as we have found the number
    end;
  end;
end;

procedure TMain_Form.CompileStats(Sender: TObject);
const
STATS_COL_WIDTH = 50;
STATS_STRINGGRID_WIDTH = 400;
var
qc_zones_2d_array, on_zones_2d_array: array[0..7] of array of String;
i, j, num_qso_in_zone: Integer;
dupes_lines_array: array of Integer;
begin
   num_ph_qso_qc := 0;
   num_cw_qso_qc := 0;
   num_ph_qso_on := 0;
   num_cw_qso_on := 0;
   num_qso_total_qc := 0;
   num_qso_total_on := 0;
   num_bonus_stations_qc := 0;
   num_bonus_stations_on := 0;
   num_mult_tot := 0;
   num_mult_in_qcqp := 0;
   num_mult_in_onqp := 0;
   num_dupes_ph := 0;
   num_dupes_cw := 0;
   num_dupes_tot := 0;
   mobile_bonus_Zones_qc := 0;
   mobile_bonus_Zones_on := 0;
   num_qso_in_zone := 0;
   SetLength(zones_qc, 0);
   SetLength(zones_on, 0);
   SetLength(myZones_qc, 0);
   SetLength(myZones_on, 0);
   SetLength(dupes_lines_array,0);
   for i := 0 to High(FREQS_ARRAY) do
   begin
         SetLength(qc_zones_2d_array[i], 0);                                   // Clears the array
         SetLength(on_zones_2d_array[i], 0);                                   // Clears the array
   end;

   // Quebec QSO Party's point of view
   if (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [0,2]) then
   begin
      // Check for dupes from the QCQP's perspective
      for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
      begin
          for row_index2 := (row_index + 1) to (QSO_List_StringGrid.RowCount - 1) do
          begin
             if ((Main_Form.QSO_List_StringGrid.Cells[3,row_index2] = QSO_List_StringGrid.Cells[3,row_index])      // Callsign check
                and (QSO_List_StringGrid.Cells[5,row_index2] = QSO_List_StringGrid.Cells[5,row_index])   // DX Zone check
                and ((QSO_List_StringGrid.Cells[2,row_index2] = QSO_List_StringGrid.Cells[2,row_index])
                     or ((QSO_List_StringGrid.Cells[2,row_index2] = 'FM') and (QSO_List_StringGrid.Cells[2,row_index] = 'SSB'))
                     or ((QSO_List_StringGrid.Cells[2,row_index2] = 'SSB') and (QSO_List_StringGrid.Cells[2,row_index] = 'FM')))  // Mode
                and (QSO_List_StringGrid.Cells[1,row_index2] = QSO_List_StringGrid.Cells[1,row_index])   // Band
                and (QSO_List_StringGrid.Cells[6,row_index2] = QSO_List_StringGrid.Cells[6,row_index])   // Party
                and ((QSO_List_StringGrid.Cells[7,row_index2] = QSO_List_StringGrid.Cells[7,row_index])  // Local zone check
                     or (QSO_List_StringGrid.Cells[7,row_index2] in ON_ZONES_ARRAY)) // Must be considered an ON QSO, even if ON station is mobile and in a different ON zone.
                and not(IsNumberInArray(dupes_lines_array, row_index2))) then
                begin
                  if (QSO_List_StringGrid.Cells[2,row_index] in PH_MODES_ARRAY) then
                  begin
                    Inc(num_dupes_ph);
                  end
                  else if (QSO_List_StringGrid.Cells[2,row_index] = 'CW') then
                  begin
                    Inc(num_dupes_cw);
                  end;
                  Insert(row_index2, dupes_lines_array, 0);      // Add the number of the row that is a duplicate to the duplicates list.
                end;
          end;
      end;
     for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
     begin
       // Count number of CW and SSB contacts from QC
       if ((QSO_List_StringGrid.Cells[5,row_index] <> 'QC') and (QSO_List_StringGrid.Cells[2,row_index] in PH_MODES_ARRAY)) then Inc(num_ph_qso_qc)
       else if ((QSO_List_StringGrid.Cells[5,row_index] <> 'QC') and (QSO_List_StringGrid.Cells[2,row_index] = 'CW')) then Inc(num_cw_qso_qc);
       // Count the number of sponsor stations in  QC zones
       if ((QSO_List_StringGrid.Cells[3,row_index] in QC_SPONSOR_ARRAY) and not(IsNumberInArray(dupes_lines_array, row_index))) then Inc(num_bonus_stations_qc);
       // Count the number of zones the operator worked from in QC. Any number > 1 is considered a mobile station. This does not correspond to the number of activated zones.
       if (not(QSO_List_StringGrid.Cells[7,row_index] in myZones_qc) and (QSO_List_StringGrid.Cells[7,row_index] in QC_ZONES_ARRAY) and not(IsNumberInArray(dupes_lines_array, row_index))) then Insert(QSO_List_StringGrid.Cells[7,row_index],myZones_qc,0);
     end;
     // A station outside of QC, count the number of unique QC zones worked
     if (Length(myZones_qc) = 0) then
     begin
          for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
          begin
            if ((QSO_List_StringGrid.Cells[5,row_index] in QC_ZONES_ARRAY)
                and (not(QSO_List_StringGrid.Cells[5,row_index] in qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                and not(IsNumberInArray(dupes_lines_array, row_index)))
              then Insert(QSO_List_StringGrid.Cells[5,row_index], qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
          end;
          // For outside of QC stations, compute the total number of multipliers
          for i := 0 to High(FREQS_ARRAY) do
          begin
              num_mult_in_qcqp := num_mult_in_qcqp + Length(qc_zones_2d_array[i]);
              SetLength(qc_zones_2d_array[i], 0);                                   // Clears the array for that frequency
          end;
     end
     // A QC station since myZones_qc > 0
     else begin
       // For a QC station (mobiles incl.), count the number of unique zones worked in QC.
       for zone_index := 0 to High(myZones_qc) do                 // Scan through the various zones the station worked from.
       begin
            for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
            begin
              // Count number of QSOs with QC Zones
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_qc[zone_index])
                  and (QSO_List_StringGrid.Cells[5,row_index] in QC_ZONES_ARRAY)
                  and (not(QSO_List_StringGrid.Cells[5,row_index] in qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                  and not(IsNumberInArray(dupes_lines_array, row_index)))
                then Insert(QSO_List_StringGrid.Cells[5,row_index], qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
              // For mobiles, count number of QSOs from within that zone (a minimum of 3 for that zone activation to be counted)
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_qc[zone_index]) and not(IsNumberInArray(dupes_lines_array, row_index)))
                then num_qso_in_zone := num_qso_in_zone + 1;   // For mobile stations
              // Count number of QSOs with outside of QC zones
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_qc[zone_index])
                 and (QSO_List_StringGrid.Cells[5,row_index] in OTHER_ZONES_ARRAY)
                 and (QSO_List_StringGrid.Cells[5,row_index] <> 'QC')   // QC is in the OTHER_ZONES_ARRAY but must be excluded here
                 and (not(QSO_List_StringGrid.Cells[5,row_index] in qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                 and not(IsNumberInArray(dupes_lines_array, row_index)))
               then Insert(QSO_List_StringGrid.Cells[5,row_index], qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
              //// Count number of QSOs with ON stations reported as ON three-letter zones. Substitute with 'ON'
              //if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_qc[zone_index])
              //   and (QSO_List_StringGrid.Cells[5,row_index] in ON_ZONES_ARRAY)
              //   and (not('ON' in qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
              //   and not(IsNumberInArray(dupes_lines_array, row_index)))
              // then Insert('ON', qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
              // Count number of QSOs with ON stations reported as ON three-letter zones. Allow the use of ON three-letter zones to be counted as separate zones (from mobile station)
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_qc[zone_index])
                 and (QSO_List_StringGrid.Cells[5,row_index] in ON_ZONES_ARRAY)
                 and (not(QSO_List_StringGrid.Cells[5,row_index] in qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                 and not(IsNumberInArray(dupes_lines_array, row_index)))
               then Insert(QSO_List_StringGrid.Cells[5,row_index], qc_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
           end;
           // For mobiles, count the number of bonus zones activated
           if ((Length(myZones_qc) > 1) and (num_qso_in_zone >= 3)) then mobile_bonus_Zones_qc := mobile_bonus_Zones_qc + 1;
           num_qso_in_zone := 0;
           // Compute the total number of multipliers. This is done after each activated QC zone
           for i := 0 to High(FREQS_ARRAY) do
           begin
                num_mult_in_qcqp := num_mult_in_qcqp + Length(qc_zones_2d_array[i]);
                SetLength(qc_zones_2d_array[i], 0);                                   // Clears the array for that frequency
           end;
       end;
    end;
   end;
   SetLength(dupes_lines_array,0);
   // Ontario QSO Party's point of view
   if (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [1,2]) then
   begin
      // Check for dupes from the ONQP's perspective
      for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
      begin
          for row_index2 := (row_index + 1) to (QSO_List_StringGrid.RowCount - 1) do
          begin
             if ((Main_Form.QSO_List_StringGrid.Cells[3,row_index2] = QSO_List_StringGrid.Cells[3,row_index])      // Callsign check
                and (QSO_List_StringGrid.Cells[5,row_index2] = QSO_List_StringGrid.Cells[5,row_index])   // DX Zone check
                and ((QSO_List_StringGrid.Cells[2,row_index2] = QSO_List_StringGrid.Cells[2,row_index])
                     or ((QSO_List_StringGrid.Cells[2,row_index2] = 'FM') and (QSO_List_StringGrid.Cells[2,row_index] = 'SSB'))
                     or ((QSO_List_StringGrid.Cells[2,row_index2] = 'SSB') and (QSO_List_StringGrid.Cells[2,row_index] = 'FM')))  // Mode
                and (QSO_List_StringGrid.Cells[1,row_index2] = QSO_List_StringGrid.Cells[1,row_index])   // Band
                and (QSO_List_StringGrid.Cells[6,row_index2] = QSO_List_StringGrid.Cells[6,row_index])   // Party
                and ((QSO_List_StringGrid.Cells[7,row_index2] = QSO_List_StringGrid.Cells[7,row_index])  // Local zone check
                     or (QSO_List_StringGrid.Cells[7,row_index2] in QC_ZONES_ARRAY)) // Must be considered an QC QSO, even if QC station is mobile and in a different QC zone.
                and not(IsNumberInArray(dupes_lines_array, row_index2))) then
                begin
                  if (QSO_List_StringGrid.Cells[2,row_index] in PH_MODES_ARRAY) then
                  begin
                    Inc(num_dupes_ph);
                  end
                  else if (QSO_List_StringGrid.Cells[2,row_index] = 'CW') then
                  begin
                    Inc(num_dupes_cw);
                  end;
                  Insert(row_index2, dupes_lines_array, 0);      // Add the number of the row that is a duplicate to the duplicates list.
                end;
          end;
      end;
     for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
     begin
       // Count number of CW and SSB contacts from ON
       if ((QSO_List_StringGrid.Cells[5,row_index] <> 'ON') and (QSO_List_StringGrid.Cells[2,row_index] in PH_MODES_ARRAY)) then Inc(num_ph_qso_on)
       else if ((QSO_List_StringGrid.Cells[5,row_index] <> 'ON') and (QSO_List_StringGrid.Cells[2,row_index] = 'CW')) then Inc(num_cw_qso_on);
       // Count the number of sponsor stations in  ON zones
       if ((QSO_List_StringGrid.Cells[3,row_index] in ON_SPONSOR_ARRAY) and not(IsNumberInArray(dupes_lines_array, row_index))) then Inc(num_bonus_stations_on);
       // Count the number of zones the operator worked from in ON. Any number > 1 is considered a mobile station. This does not correspond to the number of activated zones.
       if (not(QSO_List_StringGrid.Cells[7,row_index] in myZones_on) and (QSO_List_StringGrid.Cells[7,row_index] in ON_ZONES_ARRAY) and not(IsNumberInArray(dupes_lines_array, row_index))) then Insert(QSO_List_StringGrid.Cells[7,row_index],myZones_on,0);
     end;
     // A station outside of ON, count the number of unique ON zones worked
     if (Length(myZones_on) = 0) then
     begin
          for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
          begin
            if ((QSO_List_StringGrid.Cells[5,row_index] in ON_ZONES_ARRAY)
                and (not(QSO_List_StringGrid.Cells[5,row_index] in on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                and not(IsNumberInArray(dupes_lines_array, row_index)))
              then Insert(QSO_List_StringGrid.Cells[5,row_index], on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
          end;
          // For outside of ON stations, compute the total number of multipliers
          for i := 0 to High(FREQS_ARRAY) do
          begin
              num_mult_in_onqp := num_mult_in_onqp + Length(on_zones_2d_array[i]);
              SetLength(on_zones_2d_array[i], 0);                                   // Clears the array for that frequency
          end;
     end
     // A ON station since myZones_on > 0
     else begin
       // For a ON station (mobiles incl.), count the number of unique zones worked in ON.
       for zone_index := 0 to High(myZones_on) do                 // Scan through the various zones the station worked from.
       begin
            for row_index := 1 to (QSO_List_StringGrid.RowCount - 1) do
            begin
              // Count number of QSOs with ON Zones
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_on[zone_index])
                  and (QSO_List_StringGrid.Cells[5,row_index] in ON_ZONES_ARRAY)
                  and (not(QSO_List_StringGrid.Cells[5,row_index] in on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                  and not(IsNumberInArray(dupes_lines_array, row_index)))
                then Insert(QSO_List_StringGrid.Cells[5,row_index], on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
              // For mobiles, count number of QSOs from within that zone (a minimum of 3 for that zone activation to be counted)
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_on[zone_index]) and not(IsNumberInArray(dupes_lines_array, row_index)))
                then num_qso_in_zone := num_qso_in_zone + 1;   // For mobile stations
              // Count number of QSOs with outside of ON zones
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_on[zone_index])
                 and (QSO_List_StringGrid.Cells[5,row_index] in OTHER_ZONES_ARRAY)
                 and (QSO_List_StringGrid.Cells[5,row_index] <> 'ON')   // ON is in the OTHER_ZONES_ARRAY but must be excluded here
                 and (not(QSO_List_StringGrid.Cells[5,row_index] in on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                 and not(IsNumberInArray(dupes_lines_array, row_index)))
               then Insert(QSO_List_StringGrid.Cells[5,row_index], on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
              // Count number of QSOs with QC stations reported as three-letter QC zones. Substitute with 'QC'
              if ((QSO_List_StringGrid.Cells[7,row_index] = myZones_on[zone_index])
                 and (QSO_List_StringGrid.Cells[5,row_index] in QC_ZONES_ARRAY)
                 and (not('QC' in on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])]))
                 and not(IsNumberInArray(dupes_lines_array, row_index)))
               then Insert('QC', on_zones_2d_array[ArrayIndex(FREQS_ARRAY, QSO_List_StringGrid.Cells[1,row_index])],0);
           end;
           // For mobiles, count the number of bonus zones activated
           if ((Length(myZones_on) > 1) and (num_qso_in_zone >= 3)) then mobile_bonus_Zones_on := mobile_bonus_Zones_on + 1;
           num_qso_in_zone := 0;
           // Compute the total number of multipliers. This is done after each activated ON zone
           for i := 0 to High(FREQS_ARRAY) do
           begin
                num_mult_in_onqp := num_mult_in_onqp + Length(on_zones_2d_array[i]);
                SetLength(on_zones_2d_array[i], 0);                                   // Clears the array for that frequency
           end;
       end;
     end;
   end;
      // Calculate the results
   num_qso_total_qc :=  num_ph_qso_qc + num_cw_qso_qc;
   num_qso_total_on :=  num_ph_qso_on + num_cw_qso_on;
   num_dupes_tot := num_dupes_ph + num_dupes_cw;
   qso_score_in_qcqp :=  (((num_ph_qso_qc - num_dupes_ph)          //PH QSO 1 pt, CW QSO 2 pt.
                       + ((num_cw_qso_qc - num_dupes_cw) * 2))
                       * num_mult_in_qcqp);
   qso_score_in_onqp :=  ((((num_ph_qso_on- num_dupes_ph) * 2)      // New in 2026: 2 point for both phone and CW QSOs.
                       + ((num_cw_qso_on - num_dupes_cw) * 2))
                       * num_mult_in_onqp);
   bonus_tot_qc := (mobile_bonus_Zones_qc * 300) + (num_bonus_stations_qc * 10);
   bonus_tot_on := (mobile_bonus_Zones_on * 300) + (num_bonus_stations_on * 10);
   total_score_in_qcqp := qso_score_in_qcqp + bonus_tot_qc;
   total_score_in_onqp := qso_score_in_onqp + bonus_tot_on;
   // Display the results
   with Statistics_Form.Stats_StringGrid do
   begin
       // Display QCQP stats
       Cells[1,1] := IntToStr(num_ph_qso_qc);
       Cells[1,2] := IntToStr(num_cw_qso_qc);
       Cells[1,3] := IntToStr(num_qso_total_qc);
       Cells[1,4] := IntToStr(num_dupes_ph);
       Cells[1,5] := IntToStr(num_dupes_cw);
       Cells[1,6] := IntToStr(num_dupes_tot);
       Cells[1,7] := IntToStr(Length(myZones_qc));
       Cells[1,8] := IntToStr(mobile_bonus_Zones_qc);
       Cells[1,9] := IntToStr(num_bonus_stations_qc);
       Cells[1,10] := IntToStr(num_mult_in_qcqp);
       Cells[1,11] := IntToStr(qso_score_in_qcqp);
       Cells[1,12] := IntToStr(bonus_tot_qc);
       Cells[1,13] := IntToStr(total_score_in_qcqp);
       // Display ONQP stats
       Cells[2,1] := IntToStr(num_ph_qso_on);
       Cells[2,2] := IntToStr(num_cw_qso_on);
       Cells[2,3] := IntToStr(num_qso_total_on);
       Cells[2,4] := IntToStr(num_dupes_ph);
       Cells[2,5] := IntToStr(num_dupes_cw);
       Cells[2,6] := IntToStr(num_dupes_tot);
       Cells[2,7] := IntToStr(Length(myZones_on));
       Cells[2,8] := IntToStr(mobile_bonus_Zones_on);
       Cells[2,9] := IntToStr(num_bonus_stations_on);
       Cells[2,10] := IntToStr(num_mult_in_onqp);
       Cells[2,11] := IntToStr(qso_score_in_onqp);
       Cells[2,12] := IntToStr(bonus_tot_on);
       Cells[2,13] := IntToStr(total_score_in_onqp);
       // Show/Hide the columns based on which party participated
       if (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 0) then
       begin
         ColWidths[1]:=STATS_COL_WIDTH;  // QC, hide ON
         ColWidths[2]:=0;  // QC, hide ON
         Statistics_Form.Width := STATS_STRINGGRID_WIDTH - STATS_COL_WIDTH;
       end
       else if (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 1) then
       begin
         ColWidths[2]:=STATS_COL_WIDTH;  // QC, hide ON
         ColWidths[1]:=0;  // QC, hide ON
         Statistics_Form.Width := STATS_STRINGGRID_WIDTH - STATS_COL_WIDTH;
       end
       else begin
         ColWidths[2]:=STATS_COL_WIDTH;  // QC, hide ON
         ColWidths[1]:=STATS_COL_WIDTH;  // QC, hide ON
         Statistics_Form.Width := STATS_STRINGGRID_WIDTH;
       end;
   end;
//   Statistics_Form.AutoSize := False;
//   Statistics_Form.AutoSize := True;
//   Statistics_Form.AdjustSize;
end;
end.




