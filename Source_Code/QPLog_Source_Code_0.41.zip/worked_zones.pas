unit worked_zones;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Grids, ExtCtrls,
  StdCtrls, ComCtrls, EditBtn, StrUtils, Types, Main_Window, lang_select, QSO_Entry;

type

  { TWorked_Zones_Form }

  TWorked_Zones_Form = class(TForm)
    Band_Listboxes_ON_Panel: TPanel;
    InProvince_Label: TLabel;
    Bonus_Label: TLabel;
    Not_Counted_Label: TLabel;
    ON_Title_Panel: TPanel;
    QC_Title_Panel: TPanel;
    QC_Label: TLabel;
    ON_Label: TLabel;
    ON_Label_10m: TLabel;
    ON_Label_15m: TLabel;
    ON_Label_160m: TLabel;
    ON_Label_20m: TLabel;
    ON_Label_2m: TLabel;
    ON_Label_40m: TLabel;
    ON_Label_6m: TLabel;
    ON_Label_80m: TLabel;
    ON_ListBox_10m: TListBox;
    ON_ListBox_15m: TListBox;
    ON_ListBox_160m: TListBox;
    ON_ListBox_20m: TListBox;
    ON_ListBox_2m: TListBox;
    ON_ListBox_40m: TListBox;
    ON_ListBox_6m: TListBox;
    ON_ListBox_80m: TListBox;
    OutOfProvince_Label: TLabel;
    QC_Label_2m: TLabel;
    QC_Label_6m: TLabel;
    QC_Label_10m: TLabel;
    QC_Label_15m: TLabel;
    QC_Label_20m: TLabel;
    QC_Label_40m: TLabel;
    QC_ListBox_2m: TListBox;
    QC_ListBox_6m: TListBox;
    QC_ListBox_10m: TListBox;
    QC_ListBox_15m: TListBox;
    QC_ListBox_20m: TListBox;
    QC_ListBox_40m: TListBox;
    Legend_Panel: TPanel;
    Band_Listboxes_QC_Panel: TPanel;
    Stats_Panel: TPanel;
    Title_Panel: TPanel;
    ON_Panel_10m: TPanel;
    ON_Panel_15m: TPanel;
    ON_Panel_160m: TPanel;
    ON_Panel_20m: TPanel;
    QC_Panel_2m: TPanel;
    ON_Panel_2m: TPanel;
    ON_Panel_40m: TPanel;
    QC_Panel_6m: TPanel;
    QC_Panel_10m: TPanel;
    QC_Panel_15m: TPanel;
    QC_Panel_20m: TPanel;
    QC_Panel_40m: TPanel;
    QC_Label_160m: TLabel;
    QC_Label_80m: TLabel;
    QC_ListBox_160m: TListBox;
    QC_ListBox_80m: TListBox;
    Panel_160m: TPanel;
    ON_Panel_6m: TPanel;
    QC_Panel_80m: TPanel;
    ON_Panel_80m: TPanel;
    Worked_Zones_Refresh_Timer: TTimer;
    procedure Band_Listboxes_QC_PanelClick(Sender: TObject);
    procedure Bonus_LabelClick(Sender: TObject);
    procedure InProvince_LabelClick(Sender: TObject);
    procedure ON_LabelClick(Sender: TObject);
    procedure QC_Label_160mClick(Sender: TObject);
    procedure QC_Label_20mClick(Sender: TObject);
    procedure ON_Panel_15mClick(Sender: TObject);
    procedure Panel_160mClick(Sender: TObject);
    procedure QC_Panel_20mClick(Sender: TObject);
    procedure QC_Panel_2mClick(Sender: TObject);
    procedure QC_Panel_40mClick(Sender: TObject);
    procedure QC_Panel_80mClick(Sender: TObject);
    procedure Worked_Zones_Form_OnKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Worked_Zones_Form_OnResize(Sender: TObject);
    procedure Worked_Zones_Form_OnShow(Sender: TObject);
    procedure Zone_Listboxes_GroupBoxClick(Sender: TObject);
    procedure QC_ListBox_160mClick(Sender: TObject);
    procedure Zones_Refresh_Timer_OnTimer(Sender: TObject);
    procedure Zone_Listbox_OndrawItem(Control: TWinControl; Index: Integer;
      ARect: TRect; State: TOwnerDrawState);
    procedure Worked_Zones_Form_OnCreate(Sender: TObject);
    procedure Update_Zone_ListBoxes(Sender: TObject);

  private

  public

  end;

var
  Worked_Zones_Form: TWorked_Zones_Form;

const
   {$IFDEF MSWindows}
   In_Prov_Color: Tcolor  = $006400;
   Out_Prov_Color: Tcolor = $800000;
   Bonus_Color: Tcolor    = $800080;
   Not_Counted_Color      = $808080;
   {$ELSE}
   In_Prov_Color: Tcolor  = clGreen;
   Out_Prov_Color: Tcolor = clBlue;
   Not_Counted_Color = clGray;
   Bonus_Color: Tcolor    = clRed;
  {$ENDIF}

implementation
uses Log_Setup;

{$R *.lfm}

{ TWorked_Zones_Form }

procedure TWorked_Zones_Form.Zone_Listboxes_GroupBoxClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.QC_Panel_2mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.QC_Panel_20mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.Panel_160mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.Band_Listboxes_QC_PanelClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.Bonus_LabelClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.InProvince_LabelClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.ON_LabelClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.QC_Label_160mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.QC_Label_20mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.ON_Panel_15mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.QC_Panel_40mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.QC_Panel_80mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.Worked_Zones_Form_OnKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
     if (Key in [112..123]) then        // One of F1-F12 Function keys pressed.
     begin
       QSO_Entry_Form.Send_Keyer_Command(IntToStr(Ord(Key)));
     end;
     if ((Key = 27) and (Keyer_Support_Present)) then QSO_Entry_Form.Send_Keyer_Command('27');         // Escape key pressed, send Escape code to keyer to stop CW.
     Key:= 0;
end;

procedure TWorked_Zones_Form.Worked_Zones_Form_OnResize(Sender: TObject);
begin
   if Log_Setup_Form.Party_Select_RadioGroup.ItemIndex = 2 then
   begin
   Band_Listboxes_QC_Panel.Height := Round((Worked_Zones_Form.ClientHeight - Legend_Panel.Height) / 2);
   Band_Listboxes_ON_Panel.Height := Band_Listboxes_QC_Panel.Height;
   QC_Title_Panel.Height := Round(Title_Panel.Height / 2) + 1;
   ON_Title_Panel.Height := Round(Title_Panel.Height / 2) + 1;
  end;

end;

procedure TWorked_Zones_Form.Worked_Zones_Form_OnShow(Sender: TObject);
begin
end;

procedure TWorked_Zones_Form.QC_ListBox_160mClick(Sender: TObject);
begin

end;

procedure TWorked_Zones_Form.Zones_Refresh_Timer_OnTimer(Sender: TObject);
begin
  if (Main_Form.QSO_List_StringGrid.RowCount > 1) then Update_Zone_ListBoxes(Nil);
end;

// Called when a string is added to a zone listbox to center text
procedure TWorked_Zones_Form.Zone_Listbox_OndrawItem(Control: TWinControl;
  Index: Integer; ARect: TRect; State: TOwnerDrawState);
var
   ts: TTextStyle;
begin
  (Control as TListBox).Canvas.FillRect(ARect);
   ts := (Control as TListBox).Canvas.TextStyle;
   ts.Alignment := taCenter;
   ts.Layout := tlCenter;
   Case Log_Setup_Form.Party_Select_RadioGroup.ItemIndex of
        0: begin
               if ((Control as TListBox).Items[Index] in QC_ZONES_ARRAY) then (Control as TListBox).Canvas.Font.Color := In_Prov_Color
               else if ((Control as TListBox).Items[Index] = 'QC') then (Control as TListBox).Canvas.Font.Color := Not_Counted_Color
               else if (((Control as TListBox).Items[Index] in ON_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
               else if (((Control as TListBox).Items[Index] = 'ON')) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
               else if (((Control as TListBox).Items[Index] in OTHER_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
               else (Control as TListBox).Canvas.Font.Color := Not_Counted_Color;
           end;
        1: begin
               if ((Control as TListBox).Items[Index] in ON_ZONES_ARRAY) then (Control as TListBox).Canvas.Font.Color := In_Prov_Color
               else if ((Control as TListBox).Items[Index] = 'ON') then (Control as TListBox).Canvas.Font.Color := Not_Counted_Color
               else if (((Control as TListBox).Items[Index] in QC_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
               else if (((Control as TListBox).Items[Index] = 'QC')) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
               else if (((Control as TListBox).Items[Index] in OTHER_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
               else (Control as TListBox).Canvas.Font.Color := Not_Counted_Color;
           end;
        2: begin
               // QCQP portion
               if (copy(Control.Name,0,3) = 'QC_') then
               begin
                    if ((Control as TListBox).Items[Index] in QC_ZONES_ARRAY) then (Control as TListBox).Canvas.Font.Color := In_Prov_Color
                    else if ((Control as TListBox).Items[Index] = 'QC') then (Control as TListBox).Canvas.Font.Color := Not_Counted_Color
                    else if (((Control as TListBox).Items[Index] in ON_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
                    else if (((Control as TListBox).Items[Index] in OTHER_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color;
               end
               // ONQP portion
               else if (copy(Control.Name,0,3) = 'ON_') then
               begin
                    if ((Control as TListBox).Items[Index] in ON_ZONES_ARRAY) then (Control as TListBox).Canvas.Font.Color := In_Prov_Color
                    else if ((Control as TListBox).Items[Index] = 'ON') then (Control as TListBox).Canvas.Font.Color := Not_Counted_Color
                    else if (((Control as TListBox).Items[Index] in QC_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
                    else if (((Control as TListBox).Items[Index] in OTHER_ZONES_ARRAY)) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color
                    else if (((Control as TListBox).Items[Index] = 'QC')) then (Control as TListBox).Canvas.Font.Color := Out_Prov_Color;
               end
               // Everythng else not caught yet
               else (Control as TListBox).Canvas.Font.Color := Not_Counted_Color;
           end;
   end;
   if (Length((Control as TListBox).Items[Index]) > 3) then (Control as TListBox).Canvas.Font.Color := Bonus_Color;
  (Control as TListBox).Canvas.TextRect(ARect, 0, 0, (Control as TListBox).Items[Index], ts);
end;

procedure TWorked_Zones_Form.Worked_Zones_Form_OnCreate(Sender: TObject);   // Centers the text horizontally and vertically in the stringgrid boxes
begin
  InProvince_Label.Font.Color := In_Prov_Color;
  OutOfProvince_Label.Font.Color := Out_Prov_Color;
  Bonus_Label.Font.Color := Bonus_Color;
end;

procedure TWorked_Zones_Form.Update_Zone_ListBoxes(Sender: TObject);   // Centers the text horizontally and vertically in the stringgrid boxes
var
  row_index, freq_index , i: Integer;
begin
    // Erase the Worked zones and sponsors arrays for all bands
  for i:= 0 to 7 do
  begin
    SetLength(qc_worked_zones_2d_array[i],0);
    SetLength(on_worked_zones_2d_array[i],0);
    SetLength(qc_worked_Sponsor_2d_array[i],0);
    SetLength(on_worked_Sponsor_2d_array[i],0);
  end;
  freq_index := 0;
  for freq_index := 0 to (High(FREQS_ARRAY)) do
    for row_index := 1 to (Main_Form.QSO_List_StringGrid.RowCount - 1) do
    begin
         if ((Main_Form.QSO_List_StringGrid.Cells[1,row_index] = FREQS_ARRAY[freq_index])  // Selects the band (frequency)
             and not(Main_Form.QSO_List_StringGrid.Cells[5,row_index] in qc_worked_zones_2d_array[freq_index])) then  // Verifies if not already in the worked array for that band
            Insert(Main_Form.QSO_List_StringGrid.Cells[5,row_index], qc_worked_zones_2d_array[freq_index], High(qc_worked_zones_2d_array[freq_index]) + 1);
//         if ((Main_Form.QSO_List_StringGrid.Cells[1,row_index] = FREQS_ARRAY[freq_index]) and (not('ON' in qc_worked_zones_2d_array[freq_index]))
//             and (Main_Form.QSO_List_StringGrid.Cells[5,row_index] in ON_ZONES_ARRAY)) then insert('ON',qc_worked_zones_2d_array[freq_index],0);
         if ((Main_Form.QSO_List_StringGrid.Cells[1,row_index] = FREQS_ARRAY[freq_index])  // Selects the band (frequency)
             and not(Main_Form.QSO_List_StringGrid.Cells[5,row_index] in on_worked_zones_2d_array[freq_index])) then // Verifies if not already in the worked array for that band
            Insert(Main_Form.QSO_List_StringGrid.Cells[5,row_index], on_worked_zones_2d_array[freq_index], High(on_worked_zones_2d_array[freq_index]) + 1);
//         if ((Main_Form.QSO_List_StringGrid.Cells[1,row_index] = FREQS_ARRAY[freq_index]) and (not('QC' in on_worked_zones_2d_array[freq_index]))
//             and (Main_Form.QSO_List_StringGrid.Cells[5,row_index] in QC_ZONES_ARRAY)) then insert('QC',on_worked_zones_2d_array[freq_index],0);
    end;
  // This part updates the 8 band listboxes with the info in the 2-dimension array
  QC_ListBox_160m.Clear;
  QC_ListBox_160m.Clear;
  QC_ListBox_80m.Clear;
  QC_ListBox_40m.Clear;
  QC_ListBox_20m.Clear;
  QC_ListBox_15m.Clear;
  QC_ListBox_10m.Clear;
  QC_ListBox_6m.Clear;
  QC_ListBox_2m.Clear;
  ON_ListBox_160m.Clear;
  ON_ListBox_80m.Clear;
  ON_ListBox_40m.Clear;
  ON_ListBox_20m.Clear;
  ON_ListBox_15m.Clear;
  ON_ListBox_10m.Clear;
  ON_ListBox_6m.Clear;
  ON_ListBox_2m.Clear;
  // QC listboxes
  for i := 0 to (Length(qc_worked_zones_2d_array[0]) - 1) do QC_ListBox_160m.Items.Add(qc_worked_zones_2d_array[0,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[1]) - 1) do QC_ListBox_80m.Items.Add(qc_worked_zones_2d_array[1,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[2]) - 1) do QC_ListBox_40m.Items.Add(qc_worked_zones_2d_array[2,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[3]) - 1) do QC_ListBox_20m.Items.Add(qc_worked_zones_2d_array[3,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[4]) - 1) do QC_ListBox_15m.Items.Add(qc_worked_zones_2d_array[4,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[5]) - 1) do QC_ListBox_10m.Items.Add(qc_worked_zones_2d_array[5,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[6]) - 1) do QC_ListBox_6m.Items.Add(qc_worked_zones_2d_array[6,i]);
  for i := 0 to (Length(qc_worked_zones_2d_array[7]) - 1) do QC_ListBox_2m.Items.Add(qc_worked_zones_2d_array[7,i]);
  // QC listboxes
  for i := 0 to (Length(on_worked_zones_2d_array[0]) - 1) do ON_ListBox_160m.Items.Add(on_worked_zones_2d_array[0,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[1]) - 1) do ON_ListBox_80m.Items.Add(on_worked_zones_2d_array[1,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[2]) - 1) do ON_ListBox_40m.Items.Add(on_worked_zones_2d_array[2,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[3]) - 1) do ON_ListBox_20m.Items.Add(on_worked_zones_2d_array[3,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[4]) - 1) do ON_ListBox_15m.Items.Add(on_worked_zones_2d_array[4,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[5]) - 1) do ON_ListBox_10m.Items.Add(on_worked_zones_2d_array[5,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[6]) - 1) do ON_ListBox_6m.Items.Add(on_worked_zones_2d_array[6,i]);
  for i := 0 to (Length(on_worked_zones_2d_array[7]) - 1) do ON_ListBox_2m.Items.Add(on_worked_zones_2d_array[7,i]);

  // Zone colors are set in the

  // This part adds the sponsoring stations
  for freq_index := 0 to (Length(FREQS_ARRAY) - 1) do
  for row_index := 1 to  (Main_Form.QSO_List_StringGrid.RowCount - 1) do
  begin
     if ((Main_Form.QSO_List_StringGrid.Cells[1,row_index] = FREQS_ARRAY[freq_index]) and (Main_Form.QSO_List_StringGrid.Cells[3,row_index] in QC_SPONSOR_ARRAY)
        and not (Main_Form.QSO_List_StringGrid.Cells[3,row_index] in qc_worked_Sponsor_2d_array[freq_index])) then
        Insert(Main_Form.QSO_List_StringGrid.Cells[3,row_index], qc_worked_Sponsor_2d_array[freq_index], High(qc_worked_Sponsor_2d_array[freq_index]) + 1);
     if ((Main_Form.QSO_List_StringGrid.Cells[1,row_index] = FREQS_ARRAY[freq_index]) and (Main_Form.QSO_List_StringGrid.Cells[3,row_index] in ON_SPONSOR_ARRAY)
        and not (Main_Form.QSO_List_StringGrid.Cells[3,row_index] in on_worked_Sponsor_2d_array[freq_index])) then
        Insert(Main_Form.QSO_List_StringGrid.Cells[3,row_index], on_worked_Sponsor_2d_array[freq_index], High(on_worked_Sponsor_2d_array[freq_index]) + 1);
  end;
  // Display the QC sponsor stations
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[0]) - 1) do QC_ListBox_160m.Items.Add(qc_worked_Sponsor_2d_array[0,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[1]) - 1) do QC_ListBox_80m.Items.Add(qc_worked_Sponsor_2d_array[1,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[2]) - 1) do QC_ListBox_40m.Items.Add(qc_worked_Sponsor_2d_array[2,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[3]) - 1) do QC_ListBox_20m.Items.Add(qc_worked_Sponsor_2d_array[3,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[4]) - 1) do QC_ListBox_15m.Items.Add(qc_worked_Sponsor_2d_array[4,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[5]) - 1) do QC_ListBox_10m.Items.Add(qc_worked_Sponsor_2d_array[5,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[6]) - 1) do QC_ListBox_6m.Items.Add(qc_worked_Sponsor_2d_array[6,i]);
  for i := 0 to (Length(qc_worked_Sponsor_2d_array[7]) - 1) do QC_ListBox_2m.Items.Add(qc_worked_Sponsor_2d_array[7,i]);
  // Display the ON sponsor stations
  for i := 0 to (Length(on_worked_Sponsor_2d_array[0]) - 1) do ON_ListBox_160m.Items.Add(on_worked_Sponsor_2d_array[0,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[1]) - 1) do ON_ListBox_80m.Items.Add(on_worked_Sponsor_2d_array[1,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[2]) - 1) do ON_ListBox_40m.Items.Add(on_worked_Sponsor_2d_array[2,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[3]) - 1) do ON_ListBox_20m.Items.Add(on_worked_Sponsor_2d_array[3,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[4]) - 1) do ON_ListBox_15m.Items.Add(on_worked_Sponsor_2d_array[4,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[5]) - 1) do ON_ListBox_10m.Items.Add(on_worked_Sponsor_2d_array[5,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[6]) - 1) do ON_ListBox_6m.Items.Add(on_worked_Sponsor_2d_array[6,i]);
  for i := 0 to (Length(on_worked_Sponsor_2d_array[7]) - 1) do ON_ListBox_2m.Items.Add(on_worked_Sponsor_2d_array[7,i]);
end;


end.

