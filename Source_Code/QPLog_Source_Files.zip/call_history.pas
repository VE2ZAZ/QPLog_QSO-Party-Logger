unit Call_History;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, CSVDocument,
  StrUtils, Types, LCLType, ExtCtrls;

type

  { TCall_History_Form }

  TCall_History_Form = class(TForm)
    History_ListBox: TListBox;
    Text_Masking_Shape: TShape;
    Station_Details_Label: TLabel;
    procedure Call_History_Form_OnCreate(Sender: TObject);
    procedure Call_History_Form_OnKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Call_History_Form_OnShow(Sender: TObject);
    procedure History_ListBox_DrawItem(Control: TWinControl; Index: Integer;
      ARect: TRect; State: TOwnerDrawState);
    procedure History_ListBox_OnClick(Sender: TObject);
    procedure History_ListBox_OnSelectionChange(Sender: TObject; User: boolean);
    procedure Missing_History_Warning_MemoChange(Sender: TObject);
    Procedure Update_Call_History_ListBox();
    procedure Load_History_CSVDocument();
    function Get_Highlighted_History_Zone():String;
    function Get_Highlighted_History_Callsign(): String;
  private

  public

  end;

var
  Call_History_Form: TCall_History_Form;
  CSV: TCSVDocument;
  Row: Integer;
  SearchStr: string;
  FieldValue: string;
  ListBox_Font_Color: TColor;


implementation

uses QSO_Entry, Main_Window, Log_Setup, worked_zones;

{$R *.lfm}

{ TCall_History_Form }

// This function returns the currently Highlighted Zone in the History StringList
function TCall_History_Form.Get_Highlighted_History_Zone(): String;
var
  StrArr: TStringArray;
begin
  result := '';

  if (History_ListBox.Items.Count > 0) then     // search yields only the first callsign, we can use it.
  begin
       StrArr := History_ListBox.Items[0].Split(' ');
       result := StrArr[Length(StrArr) - 1];
  end
//  else if (History_ListBox.Items.Count <> 1) then     // More than one callsign in list, erase zone
  else result := '';
end;

// This function returns the currently Highlighted Callsign in the History StringList
function TCall_History_Form.Get_Highlighted_History_Callsign(): String;
var
  i: Integer;
  StrArr: TStringArray;
begin
  for i := 0 to (History_ListBox.Items.Count - 1) do
  begin
       if History_ListBox.ItemIndex = i then
       begin
            StrArr := History_ListBox.Items[i].Split(' ');
            result := StrArr[0];
       end;
  end;
end;

procedure TCall_History_Form.Update_Call_History_ListBox();
var
  TempStr, tempZone: String;
  MatchPos: Integer;
begin
  History_ListBox.Items.Clear;
  Station_Details_Label.Caption := '';
  SearchStr := QSO_Entry_Form.Callsign_Entry_Edit.Text;

  for Row := 0 to CSV.RowCount - 1 do
  begin
    if CSV.ColCount[Row] = 0 then
      Continue;

    FieldValue := CSV.Cells[0, Row];
    tempZone := CSV.Cells[2, Row];

    // Skip comments / blank
    if (FieldValue <> '') and
       (FieldValue[1] <> '#') and
       (Copy(FieldValue,1,2) <> '!!') then
    begin
      MatchPos := Pos(UpperCase(SearchStr), UpperCase(FieldValue));

      if MatchPos > 0 then
      begin
        TempStr := PadRight(FieldValue, 11);       // Makes a nice aligned data in the stringlist

        // Store match position in low word, length in high word
        History_ListBox.Items.AddObject(TempStr + tempZone, TObject(PtrInt((MatchPos and $FFFF) or (Length(SearchStr) shl 16))));
        // Update displayed station details
        if ((History_ListBox.Items.Count = 1) and (QSO_Entry_Form.Callsign_Entry_Edit.Text = CSV.Cells[0, Row])) then
        begin
          Station_Details_Label.Caption := CSV.Cells[1, Row] + ' - ' + CSV.Cells[3, Row];
        end
        else Station_Details_Label.Caption := '';
      end;
    end;
  end;
  if History_ListBox.Items.Count > 0 then History_ListBox.ItemIndex := 0;   // Highlight line 0 after listbox update
  Station_Details_Label.Caption
end;

procedure TCall_History_Form.Load_History_CSVDocument();
begin
  CSV := TCSVDocument.Create;
  CSV.Delimiter := ',';
  CSV.QuoteChar := '"';
  if (Log_Setup_Form.Enable_History_CheckBox.Checked) then
  try
    CSV.LoadFromFile(history_long_filename);
//    History_ListBox.Visible := True;
  except
//      History_ListBox.Visible := False;
    Call_History_Form.Visible := False;
    MessageDlg('Erreur / Error', PChar(IfThen(french_lang, 'Échec de chargement du fichier d''Historique. Vérifier l''emplacement et le format du fichier', 'The History file failed to load. Check the file location and format')), mtError, [mbOK], 0);
  end
  else CSV.Clear;
  History_ListBox.Items.Clear;
end;

procedure TCall_History_Form.Call_History_Form_OnShow(Sender: TObject);
begin

end;

// This procedure draws the History listbox items with bold characters on matched callsign characters
procedure TCall_History_Form.History_ListBox_DrawItem(Control: TWinControl;
  Index: Integer; ARect: TRect; State: TOwnerDrawState);
var
  LB: TListBox;
  S: string;
  MatchPos, MatchLen: Integer;
  LeftPart, MidPart, RightPart: string;
  X: Integer;
  Data: PtrInt;
  StrArr: TStringArray;
begin
  LB := Control as TListBox;

  // Custom highlight
  if odSelected in State then
  begin
    LB.Canvas.Brush.Color := $0076C008;  // light green
//    LB.Canvas.Font.Color  := clBlack;
  end
  else
  begin
    LB.Canvas.Brush.Color := clWindow;
    LB.Canvas.Font.Color  := clWindowText;
  end;

  LB.Canvas.FillRect(ARect);

  S := LB.Items[Index];
  // Colorize the stringlist entries
  StrArr := S.Split(' ');
  if (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [0,2]) then
     if (StrArr[0] in QC_SPONSOR_ARRAY) then LB.Canvas.Font.Color := Bonus_Color
     else if (StrArr[Length(StrArr) - 1] in QC_ZONES_ARRAY) then LB.Canvas.Font.Color := In_Prov_Color;
  if (Log_Setup_Form.Party_Select_RadioGroup.ItemIndex in [1,2]) then
     if (StrArr[0] in ON_SPONSOR_ARRAY) then LB.Canvas.Font.Color := Bonus_Color
     else if (StrArr[Length(StrArr) - 1] in ON_ZONES_ARRAY) then LB.Canvas.Font.Color := In_Prov_Color;
  if (StrArr[Length(StrArr) - 1] in OTHER_ZONES_ARRAY) then LB.Canvas.Font.Color := Out_Prov_Color;

  // Retrieve stored match info
  Data := PtrInt(LB.Items.Objects[Index]);
  MatchPos := Data and $FFFF;
  MatchLen := (Data shr 16) and $FFFF;

  // Split string
  LeftPart  := Copy(S, 1, MatchPos - 1);
  MidPart   := Copy(S, MatchPos, MatchLen);
  RightPart := Copy(S, MatchPos + MatchLen, Length(S));

  X := ARect.Left + 2;
//  LB.Canvas.Font.Color := clRed;
  // Normal text
  LB.Canvas.Font.Style := [];
  LB.Canvas.TextOut(X, ARect.Top, LeftPart);
  Inc(X, LB.Canvas.TextWidth(LeftPart));

  // Bold match
  LB.Canvas.Font.Style := [fsBold];
  LB.Canvas.TextOut(X, ARect.Top, MidPart);
  Inc(X, LB.Canvas.TextWidth(MidPart));

  // Normal again
  LB.Canvas.Font.Style := [];
  LB.Canvas.TextOut(X, ARect.Top, RightPart);
end;

procedure TCall_History_Form.Call_History_Form_OnCreate(Sender: TObject);
begin
  Call_History_Form.Visible := False;
end;

procedure TCall_History_Form.Call_History_Form_OnKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
       if (Key in [112..123]) then        // One of F1-F12 Function keys pressed.
     begin
       QSO_Entry_Form.Send_Keyer_Command(IntToStr(Ord(Key)));
     end;
     if ((Key = 27) and (Keyer_Support_Present)) then QSO_Entry_Form.Send_Keyer_Command('27');         // Escape key pressed, send Escape code to keyer to stop CW.
     Key:= 0;
end;

procedure TCall_History_Form.History_ListBox_OnClick(Sender: TObject);
var
  i: Integer;
begin
  for i := 0 to History_ListBox.Count - 1 do
      begin
           if (History_ListBox.Selected[i]) then
           begin
//                writeln(History_ListBox.Items[i]);
                QSO_Entry_Form.Callsign_Entry_Edit.Text := Get_Highlighted_History_Callsign();
                QSO_Entry_Form.Zone_Entry_Edit.Text := '';
                QSO_Entry_Form.Callsign_Entry_Edit.SetFocus;
                QSO_Entry_Form.Callsign_Entry_Edit.SelStart := Length(QSO_Entry_Form.Callsign_Entry_Edit.Text);
                Break;
           end;
      end;
end;

procedure TCall_History_Form.History_ListBox_OnSelectionChange(Sender: TObject;
  User: boolean);
var
  i: Integer;
begin
end;

procedure TCall_History_Form.Missing_History_Warning_MemoChange(Sender: TObject
  );
begin

end;

end.

