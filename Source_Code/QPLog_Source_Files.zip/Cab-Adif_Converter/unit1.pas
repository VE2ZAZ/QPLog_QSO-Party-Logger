unit Unit1;
{

QSO Party Cabrillo to ADIF file converter
Version 0.2, 2025-04-19
By Bertrand Zauhar, VE2ZAZ - VA2IW
https://ve2zaz.net

Version History:
================
0.2 (Not released Yet):
    - Improved program termination when cancelling file selection
    - Application Icon added.
0.1 (2025/04/17): Initial release

}

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs;

const
  cab_band_list: array[0..24] of string =
    ('1800','3500','5300','7000','10100','14000','18068','21000','24890','28000',
     '50','70','144','222','432','902','1.2G','2.3G','3.4G','5.7G','10G','24G','47G','75G','122G');
  adi_band_list: array[0..24] of string =
    ('160m','80m','60m','40m','30m','20m','17m','15m','12m','10m',
     '6m','4m','2m','1.25m','70cm','33cm','23cm','13cm','9cm','6cm',
     '3cm','1.25cm','6mm','4mm','2.5mm');
  cab_mode_list: array[0..4] of string = ('CW','PH','FM','RY','DG');
  adi_mode_list: array[0..4] of string = ('CW','SSB','FM','RTTY','FT8');

type

  { TForm1 }

  TForm1 = class(TForm)
    dlg: TOpenDialog;
    procedure Form1_OnCreate(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;
  CabFile, AdiFile: TextFile;
  CabLine, AdiLine, CabFileName, AdiFileName: string;
  CabList: TStringList;
  i: Integer;
  dlg: TOpenDialog;
  zone_comment: String;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.Form1_OnCreate(Sender: TObject);
begin
  Form1.Visible := False;
  // Initialize file dialog
  try
    if not dlg.Execute then
//      Exit;
        Application.Terminate();

    CabFileName := dlg.FileName;
    AdiFileName := ChangeFileExt(CabFileName, '.adi');

    AssignFile(CabFile, CabFileName);
    Reset(CabFile);
    AssignFile(AdiFile, AdiFileName);
    Rewrite(AdiFile);

    CabList := TStringList.Create;
    try
      while not EOF(CabFile) do
      begin
        ReadLn(CabFile, CabLine);
        if CabLine = 'END-OF-LOG:' then
          Break;

        if Copy(CabLine, 1, 4) = 'QSO:' then
        begin
          CabLine := Trim(CabLine);                     // Remove anything but characters and spaces on that line
          while Pos('  ', CabLine) > 0 do
            CabLine := StringReplace(CabLine, '  ', ' ', [rfReplaceAll]);       // Remove consecutive space characters, keep only one
          CabLine := StringReplace(CabLine, #9, ' ', [rfReplaceAll]);           // Replace Tab characters with spaces
          CabLine := StringReplace(CabLine, #13#10, '', [rfReplaceAll]);        // Remove CR/LF

          CabList.Delimiter := ' ';             // Specify list creation delimiter
          CabList.StrictDelimiter := True;
          CabList.DelimitedText := CabLine;     // Create list of Cab lines

          // Band substitution to follow ADI format
          for i := Low(cab_band_list) to High(cab_band_list) do
            if CabList[1] = cab_band_list[i] then
              CabList[1] := adi_band_list[i];

          // Mode substitution to follow ADI format
          for i := Low(cab_mode_list) to High(cab_mode_list) do
            if CabList[2] = cab_mode_list[i] then
              CabList[2] := adi_mode_list[i];

          // Date formatting
          CabList[3] := StringReplace(CabList[3], '-', '', [rfReplaceAll]);

          // Zone comment creation
          zone_comment := 'My Zone: ' + CabList[7] + ' / Their Zone: ' + CabList[10];
          // Build ADIF line
          AdiLine := '<call:' + IntToStr(Length(CabList[8])) + '>' + CabList[8] + ' ' +
                     '<band:' + IntToStr(Length(CabList[1])) + '>' + CabList[1] + ' ' +
                     '<mode:' + IntToStr(Length(CabList[2])) + '>' + CabList[2] + ' ' +
                     '<qso_date:' + IntToStr(Length(CabList[3])) + '>' + CabList[3] + ' ' +
                     '<time_on:' + IntToStr(Length(CabList[4])) + '>' + CabList[4] + ' ' +
                     '<station_callsign:' + IntToStr(Length(CabList[5])) + '>' + CabList[5] + ' ' +
                     '<rst_sent:' + IntToStr(Length(CabList[6])) + '>' + CabList[6] + ' ' +
                     '<rst_rcvd:' + IntToStr(Length(CabList[9])) + '>' + CabList[9] + ' ' +
                     '<comment:' + IntToStr(Length(zone_comment)) + '>' + zone_comment + ' ' +
                     '<eor>';

          WriteLn(AdiFile, AdiLine);
        end;
      end;
    finally
      CabList.Free;
      CloseFile(CabFile);
      CloseFile(AdiFile);
    end;

    MessageDlg('Conversion Complétée / Conversion Completed.' + LineEnding + 'Fichier créé / File created:' +LineEnding + AdiFileName,    // ExtractFileName(AdiFileName)
      mtInformation, [mbOK], 0);

  finally
    dlg.Free;
  end;
  Application.Terminate();
end;
end.
