unit log_setup;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls, Worked_Zones, Main_Window, StrUtils, LCLIntf, fphttpclient, opensslsockets;

type
  { TLog_Setup_Form }
  TLog_Setup_Form = class(TForm)
    History_Download_Button: TButton;
    Enable_History_CheckBox: TCheckBox;
    History_File_Select_Button: TButton;
    History_GroupBox: TGroupBox;
    History_File_Select_OpenDialog: TOpenDialog;
    History_Filename_Label: TLabel;
    Setup_Help_Button: TButton;
    Club_LabeledEdit: TLabeledEdit;
    History_Filename_Box_Shape: TShape;
    Triangle_Shape1: TShape;
    Triangle_Shape2: TShape;
    Zone_Label: TLabel;
    Zone_ComboBox: TComboBox;
    Setup_Close_Button: TButton;
    Station_Callsign_LabeledEdit: TLabeledEdit;
    Ops_Callsign_LabeledEdit: TLabeledEdit;
    OpName_LabeledEdit: TLabeledEdit;
    Cat_OP_ComboBox: TComboBox;
    Cat_Power_ComboBox: TComboBox;
    Cat_Mode_ComboBox: TComboBox;
    Cat_Station_ComboBox: TComboBox;
    Location_ComboBox: TComboBox;
    Station_GroupBox: TGroupBox;
    Category_GroupBox: TGroupBox;
    Location_Label: TLabel;
    Party_Select_RadioGroup: TRadioGroup;
    Email_LabeledEdit: TLabeledEdit;
    Cat_Type_Label: TLabel;
    Cat_Power_Label: TLabel;
    Cat_Mode_Label: TLabel;
    Cat_Station_Type_Label: TLabel;
    procedure History_Download_ButtonClick(Sender: TObject);
    procedure Enable_History_CheckBoxChange(Sender: TObject);
    procedure History_File_Select_ButtonClick(Sender: TObject);
    procedure Setup_Help_ButtonClick(Sender: TObject);
    procedure Cat_OP_ComboBoxChange(Sender: TObject);
    procedure Cat_TX_ComboBoxChange(Sender: TObject);
    procedure Location_ComboBoxChange(Sender: TObject);
    procedure Log_Setup_Form_OnClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure Log_setup_Form_OnCreate(Sender: TObject);
    procedure Log_setup_Form_OnShow(Sender: TObject);
    procedure Party_Select_RadioGroupClick(Sender: TObject);
    procedure Station_GroupBoxClick(Sender: TObject);
    procedure Zone_ComboBox_OnChange(Sender: TObject);
    procedure ON_Only_RadioButtonChange(Sender: TObject);
    procedure Email_LabeledEditChange(Sender: TObject);
    procedure Setup_Close_ButtonClick(Sender: TObject);
    procedure Station_Callsign_LabeledEditChange(Sender: TObject);
    procedure Cat_Num_Xmit_LabelClick(Sender: TObject);
  private

  public

  end;

var
  Log_Setup_Form: TLog_Setup_Form;

implementation
uses QSO_Entry, Call_History;

{$R *.lfm}

{ TLog_Setup_Form }

procedure TLog_Setup_Form.ON_Only_RadioButtonChange(Sender: TObject);
begin

end;

procedure TLog_Setup_Form.Email_LabeledEditChange(Sender: TObject);
begin

end;

procedure TLog_Setup_Form.Setup_Close_ButtonClick(Sender: TObject);
var
  error_form : TForm;
  Message: String;
begin
  if ((Party_Select_RadioGroup.ItemIndex = -1) or ((Zone_ComboBox.Text = '---') and (Location_ComboBox.Text = '---')) or (Cat_Mode_ComboBox.Text = '')) then
  begin
    Message :=
    PChar(IfThen(french_lang,'Au minimum, les actions suivantes doivent être prises dans la fenêtre de configuration du Log:' + sLineBreak +
    ' 1- La sélection du QSO Party,' + sLineBreak +
    ' 2- Votre indicatif radio,' + sLineBreak +
    ' 3- La sélection de la Zone Provinciale, ou' + sLineBreak +
    '      l''Emplacement hors-province.' + sLineBreak +
    ' 4- Le(S) mode(s) d''opération.',
    'At a minimum, the following actions must be taken in the Log configuration window: ' + sLineBreak +
    ' 1- The selection of the QSO Party,' + sLineBreak +
    ' 2- Your radio callsign,' + sLineBreak +
    ' 3- The selection of the Provincial Zone, or' + sLineBreak +
    '      the out-of-province Location.' + sLineBreak +
    ' 4- The operation mode(s).'));
    error_form := CreateMessageDialog(Message, mtError, [mbOK]);
    error_form.Position := poOwnerFormCenter;
    error_form.ShowModal;
    Party_Select_RadioGroup.Color := $0071D1;
    Cat_Mode_ComboBox.Color := $0071D1;
    Zone_ComboBox.Color := $0071D1;
    Station_Callsign_LabeledEdit.Color := $0071D1;
    Location_ComboBox.Color := $0071D1;
  end
  else if ((Enable_History_CheckBox.Checked) and (history_long_filename = '')) then
  begin
    Message := PChar(IfThen(french_lang,'Erreur. Si l''Historique des Stations est activé, vous devez Selectionner un fichier d''Historique.',
                                        'Error. If Call History is enabled, you must select a Call History File.'));
    error_form := CreateMessageDialog(Message, mtError, [mbOK]);
    error_form.Position := poOwnerFormCenter;
    error_form.ShowModal;
  end
  else begin
    Party_Select_RadioGroup.Color := clDefault;
    Cat_Mode_ComboBox.Color := clDefault;
    Station_Callsign_LabeledEdit.Color := clDefault;
    Zone_ComboBox.Color := clDefault;
    Location_ComboBox.Color := clDefault;
    Main_Form.Select_Mode_Actions(Nil);
    Log_Setup_Form.Visible := False;
    Main_Form.Enabled := True;
    QSO_Entry_Form.Enabled := True;
    Worked_Zones_Form.Enabled := True;
    Main_Form.Save_Log_Setup(Nil);
  end;
end;

procedure TLog_Setup_Form.Station_Callsign_LabeledEditChange(Sender: TObject);
begin

end;

procedure TLog_Setup_Form.Cat_Num_Xmit_LabelClick(Sender: TObject);
begin

end;

procedure TLog_Setup_Form.Cat_TX_ComboBoxChange(Sender: TObject);
begin

end;

procedure TLog_Setup_Form.Location_ComboBoxChange(Sender: TObject);
begin
  if Location_ComboBox.ItemIndex = 0 then Zone_ComboBox.Enabled := True
  else begin
    Zone_ComboBox.ItemIndex := 0;
    Zone_ComboBox.Enabled := False;
  end;
end;

procedure TLog_Setup_Form.Cat_OP_ComboBoxChange(Sender: TObject);
begin
  if (Cat_OP_ComboBox.ItemIndex = 1) then Ops_Callsign_LabeledEdit.Enabled := True
  else Ops_Callsign_LabeledEdit.Enabled := False;
end;

procedure TLog_Setup_Form.Setup_Help_ButtonClick(Sender: TObject);
begin
  {$IFDEF MSWindows}
  OpenDocument('Help\Aide.pdf');
  {$ELSE}
  OpenDocument('./Help/Aide.pdf');
  {$ENDIF}
//  OpenDocument('./Help/Aide.pdf');
end;

procedure TLog_Setup_Form.History_File_Select_ButtonClick(Sender: TObject);
begin
  {$IFDEF MSWindows}
  History_File_Select_OpenDialog.InitialDir := '.';
  {$ELSE}
  History_File_Select_OpenDialog.InitialDir := './';
  {$ENDIF}
  History_File_Select_OpenDialog.Filter := 'History files (*.txt)|*.txt|All Files (*.*)|*.*';
  if History_File_Select_OpenDialog.Execute then
  begin
    if fileExists(History_File_Select_OpenDialog.Filename) then
    begin
      history_long_filename := History_File_Select_OpenDialog.Filename;
      History_Filename_Label.Caption := ExtractFileName(history_long_filename);
      Call_History_Form.Load_History_CSVDocument();   // Load CSVDocument with Call History file
      Call_History_Form.Visible := False;        // Will clear contents
      Call_History_Form.Visible := True;
    end;
  end;
end;

procedure TLog_Setup_Form.Enable_History_CheckBoxChange(Sender: TObject);
begin
 if (Enable_History_CheckBox.Checked) then
 begin
      Log_setup_Form.History_File_Select_Button.Enabled := True;
      Log_setup_Form.History_Download_Button.Enabled := True;
      Log_setup_Form.History_Filename_Label.Enabled := True;
      Log_setup_Form.History_Filename_Box_Shape.Enabled := True;
      if (Call_History_Form.Visible) then
      begin
          Call_History_Form.Visible := False;        // Will clear contents
          Call_History_Form.Visible := True;
      end;
      Main_Form.Call_History_Button.Enabled:= True;
 end
 else begin
     Log_setup_Form.History_File_Select_Button.Enabled := False;
     Log_setup_Form.History_Download_Button.Enabled := False;
     Log_setup_Form.History_Filename_Label.Enabled := False;
     Log_setup_Form.History_Filename_Box_Shape.Enabled := False;
     Call_History_Form.Visible := False;
     Main_Form.Call_History_Button.Enabled:= False;
 end;
end;

procedure TLog_Setup_Form.History_Download_ButtonClick(Sender: TObject);
begin
  OpenURL('https://n1mmwp.hamdocs.com/mmfiles/categories/callhistory/?CMDsearch=QSOP_');
end;

procedure TLog_Setup_Form.Log_Setup_Form_OnClose(Sender: TObject;
  var CloseAction: TCloseAction);
begin
  CloseAction := caNone;
  Setup_Close_ButtonClick(Nil);
end;

procedure TLog_Setup_Form.Log_setup_Form_OnCreate(Sender: TObject);
begin
   Log_setup_Form.Left := Main_Form.Left + 10;
   Log_setup_Form.Top := Main_Form.Top + 10;
   Location_ComboBox.Items.AddStrings(['---']);
   Location_ComboBox.Items.AddStrings(OTHER_ZONES_ARRAY);
   Location_ComboBox.ItemIndex := 0;
   Zone_ComboBox.Items.AddStrings(['---']);
   Zone_ComboBox.Items.AddStrings(QC_ZONES_ARRAY);
   Zone_ComboBox.ItemIndex := 0;

end;

procedure TLog_Setup_Form.Log_setup_Form_OnShow(Sender: TObject);
var
  warning_form : TForm;
  Message: String;
begin
  Log_setup_Form.Left := Main_Form.Left + 10;
  Log_setup_Form.Top := Main_Form.Top + 10;
  History_Filename_Label.Caption := ExtractFileName(history_long_filename);
  if (Zone_ComboBox.Items[Zone_ComboBox.ItemIndex] <> '---') then Location_ComboBox.Enabled := False
  else Location_ComboBox.Enabled := True;
  if Main_Form.QSO_List_StringGrid.RowCount > 1 then Party_Select_RadioGroup.Enabled := False;
  if ((Zone_ComboBox.Items[Zone_ComboBox.ItemIndex] = '---') and (Location_ComboBox.Items[Zone_ComboBox.ItemIndex] = '---')) then
  begin
    Message :=
       PChar(IfThen(french_lang,'Au minimum, les actions suivantes doivent être prises dans la fenêtre de configuration du Log:' + sLineBreak +
       ' 1- La sélection du QSO Party,' + sLineBreak +
       ' 2- Votre indicatif radio,' + sLineBreak +
       ' 3- La sélection de la Zone Provinciale, ou' + sLineBreak +
       '      l''Emplacement hors-province.' + sLineBreak +
       ' 4- Le(S) mode(s) d''opération.' + sLineBreak +
       'Les autres champs sont importants pour la génération du fichier Cabrillo, sinon certaines données seront manquantes.',
       'At a minimum, the following actions must be taken in the Log configuration window: ' + sLineBreak +
       ' 1- The selection of the QSO Party,' + sLineBreak +
       ' 2- Your radio callsign,' + sLineBreak +
       ' 3- The selection of the Provincial Zone, or' + sLineBreak +
       '      the out-of-province Location.' + sLineBreak +
       ' 4- The operation mode(s).' + sLineBreak +
       'The other fields are important for generating the Cabrillo file, otherwise some data will be missing.'));
    warning_form := CreateMessageDialog(Message, mtInformation, [mbOK]);
    warning_form.Position := poOwnerFormCenter;
    warning_form.ShowModal;
  end;
end;

procedure TLog_Setup_Form.Party_Select_RadioGroupClick(Sender: TObject);
begin
  Main_Form.Select_QSO_Party_Actions(Nil);
end;

procedure TLog_Setup_Form.Station_GroupBoxClick(Sender: TObject);
begin

end;

procedure TLog_Setup_Form.Zone_ComboBox_OnChange(Sender: TObject);
begin
  if Zone_ComboBox.ItemIndex > 0 then Location_ComboBox.Enabled := False
  else begin
    Location_ComboBox.ItemIndex := 0;
    Location_ComboBox.Enabled := True;
  end;
end;

end.

