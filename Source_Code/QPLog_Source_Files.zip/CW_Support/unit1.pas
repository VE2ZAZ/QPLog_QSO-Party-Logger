unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  LazSerial, LCLIntf, Spin, ComCtrls, Grids, StrUtils, Buttons, DateUtils, LazLogger,blcksock, synsock
  {$IFDEF MSWINDOWS}
  , Windows, MMSystem
  {$ENDIF};

type

  { TMain_Form }

  TMain_Form = class(TForm)
    Contest_Mode_RadioGroup: TRadioGroup;
    CW_Speed_GroupBox: TGroupBox;
    CW_Macros_GroupBox: TGroupBox;
    CQ_Repeat_Delay_Label: TLabel;
    Label2: TLabel;
    Morse_Speed_Label: TLabel;
    CQ_Repeat_RadioGroup: TRadioGroup;
    Dividing_Line_Panel: TPanel;
    Serial_Configure_Button: TButton;
    LazSerial: TLazSerial;
    Keyer_Mode_RadioGroup: TRadioGroup;
    Socket_Receive_Timer: TTimer;
    Socket_Rx_Timer: TTimer;
    CW_Speed_SpinEdit: TSpinEdit;
    CW_Phrase_Edit_Button: TButton;
    FnKeys_Display_StringGrid: TStringGrid;
    CQ_Repeat_Delay_SpinEdit: TSpinEdit;
    CQ_Repeat_Timer: TTimer;
    UDP_KeepAlive_Timer: TTimer;
    WinKeyer_Busy_Check_Timer: TTimer;
    procedure Contest_Mode_RadioGroupClick(Sender: TObject);
    procedure CQ_Repeat_Delay_SpinEdit_OnChange(Sender: TObject);
    procedure CQ_Repeat_RadioGroup_OnClick(Sender: TObject);
    procedure CQ_Repeat_Timer_OnTimer(Sender: TObject);
//    procedure CW_Interface_Rx_LUDPComponent_OnReceive(aSocket: TLSocket);
    procedure CW_Speed_SpinEditChange(Sender: TObject);
    procedure Form_OnCreate(Sender: TObject);
    procedure Socket_Receive_OnTimer(Sender: TObject);
    procedure CW_Phrase_Edit_ButtonClick(Sender: TObject);
    procedure Keyer_Mode_RadioGroupClick(Sender: TObject);
    procedure Serial_Configure_ButtonClick(Sender: TObject);
    procedure Send_FnKey_CW(FNKey: String);
    procedure Fill_FnKeys_Display_StringGrid();
    procedure InitMorseTable;
    procedure SendMorseText(const msg: string);
    procedure Socket_Receive_Timer_Ontimer(Sender: TObject);
    procedure StopCW;
    procedure UDP_KeepAlive_Timer_OnTimer(Sender: TObject);
    procedure WinKeyer_Busy_Check_OnTimer(Sender: TObject);
    procedure Switch_Language(Sender: TObject);
  private
    procedure CWThreadTerminated(Sender: TObject);
  public
  end;

  TMorseTable = array[Char] of string;

  TCWThread = class(TThread)
  private
    FText: string;
    FSerial: TLazSerial;
    FDitLenPtr: PInteger;
    procedure SendDit_DTR;
    procedure SendDah_DTR;
    procedure SendDit_RTS;
    procedure SendDah_RTS;
    procedure PreciseSleep(ms: Integer);
  protected
    procedure Execute; override;
  public
    constructor Create(const AText: string; ADitLenPtr: PInteger; ASerial: TLazSerial);
  end;

const
  ROWS = 3;
  COLS = 4;

  //Language selection constants
  sForm1_Caption : array of String = ('QPLog - Support CW', 'QPLog - CW Support');
  sForm1_Contest_Mode_RadioGroup_Caption : array of String = ('Mode d''Opération CW', 'CW Opration Mode');
  sForm1_CW_Speed_GroupBox_Caption : array of String = ('Vitesse CW', 'CW Speed');
  sForm1_Morse_Speed_Label_Caption : array of String = ('MPM', 'WPM');
  sForm1_CQ_Repeat_RadioGroup_Caption : array of String = ('Répétition de CQ', 'CQ Repetition');
  sForm1_CQ_Repeat_Delay_Label_Caption : array of String = ('Délai:', 'Delay:');
  sForm1_CW_Macros_GroupBox_Caption : array of String = ('Macros CW', 'CW Macros');
  sForm1_Keyer_CW_Phrase_Edit_Button_Caption : array of String = ('Editer Les Macros', 'Edit Macros');
  sForm1_Keyer_Mode_RadioGroup_Caption : array of String = ('Mode de Keyer', 'Keyer Mode');
  sForm1_Keyer_Mode_RadioGroup_Items_0 : array of String = ('Désactivé', 'Disabled');
  sForm1_Keyer_Mode_RadioGroup_Items_1 : array of String = ('WinKeyer', 'WinKeyer');
  sForm1_Keyer_Mode_RadioGroup_Items_2 : array of String = ('Ligne DTR', 'DTR Line');
  sForm1_Keyer_Mode_RadioGroup_Items_3 : array of String = ('Ligne RTS', 'RTS Line');
  sForm1_Serial_Configure_Button_Caption : array of String = ('Connexion au Port Série', 'Connect to Serial Port');


var
  Main_Form: TMain_Form;
  Keyer_Mode: Integer = 0;      // 0: Off, 1: Winkeyer, 2: DTR line
  MYCALL: String;
  THEIRCALL: String;
  EXCH: String;
  MorseCode: TMorseTable;
  DitLen: Integer = 50; // length of a dot in milliseconds
  Stop_Msg_Received: Boolean = False;
  CW_delay_Expired: Boolean = False;
  CurrentText: string;
  CharIndex: Integer;
  ElementIndex: Integer;
  CurrentCode: string;
  FCWThread: TCWThread;
  Manual_CW_Stopped: Boolean = False;
  In_CQ: Boolean = False;
  MacroButtons: array[0..ROWS-1,0..COLS-1] of TSpeedButton;
  Sock: TUDPBlockSocket;
  Language: Integer = 0;

implementation

{$R *.lfm}

constructor TCWThread.Create(const AText: string; ADitLenPtr: PInteger; ASerial: TLazSerial);
begin
  inherited Create(True);
  FreeOnTerminate := True;
  FText := UpperCase(AText);
  FDitLenPtr := ADitLenPtr;
  FSerial := ASerial;
  Start;
end;

{ TMain_Form }

function Calculate_Morse_Speed(Speed: Integer): Integer;
begin
  result := round(1200/speed);
end;

procedure TMain_Form.InitMorseTable;
begin
  // Initialize all to empty first
  FillChar(MorseCode, SizeOf(MorseCode), 0);

  // Letters
  MorseCode['A'] := '.-';     MorseCode['B'] := '-...';
  MorseCode['C'] := '-.-.';   MorseCode['D'] := '-..';
  MorseCode['E'] := '.';      MorseCode['F'] := '..-.';
  MorseCode['G'] := '--.';    MorseCode['H'] := '....';
  MorseCode['I'] := '..';     MorseCode['J'] := '.---';
  MorseCode['K'] := '-.-';    MorseCode['L'] := '.-..';
  MorseCode['M'] := '--';     MorseCode['N'] := '-.';
  MorseCode['O'] := '---';    MorseCode['P'] := '.--.';
  MorseCode['Q'] := '--.-';   MorseCode['R'] := '.-.';
  MorseCode['S'] := '...';    MorseCode['T'] := '-';
  MorseCode['U'] := '..-';    MorseCode['V'] := '...-';
  MorseCode['W'] := '.--';    MorseCode['X'] := '-..-';
  MorseCode['Y'] := '-.--';   MorseCode['Z'] := '--..';

  // Digits
  MorseCode['0'] := '-----';  MorseCode['1'] := '.----';
  MorseCode['2'] := '..---';  MorseCode['3'] := '...--';
  MorseCode['4'] := '....-';  MorseCode['5'] := '.....';
  MorseCode['6'] := '-....';  MorseCode['7'] := '--...';
  MorseCode['8'] := '---..';  MorseCode['9'] := '----.';

  // Symbols (add more if needed)
  MorseCode['.'] := '.-.-.-';
  MorseCode['?'] := '..--..';
  MorseCode['/'] := '-..-.';
  MorseCode['='] := '-...-';
  MorseCode[';'] := '.-.-';
  MorseCode['@'] := '.--.-.';
  MorseCode['<'] := '.-.-.';
  MorseCode['['] := '.-...';
  MorseCode['\'] := '-..-.';
  MorseCode[')'] := '-.--.-';
  MorseCode['('] := '-.--.';
  MorseCode['"'] := '.-..-.';
  MorseCode['>'] := '...-.-';
  MorseCode[''''] := '.----.';          // Two apostrophes to code one
  MorseCode['*'] := '-...-.-';   // BK
end;

procedure TMain_Form.CWThreadTerminated(Sender: TObject);
begin
  FCWThread := nil;
  Sleep(50);                       // Delay between end of DTR toggle and PTT toggle is added
  Lazserial.SetRTS(False);       // When RTS used for PTT control. Go low when CW is over.
  Lazserial.SetDTR(False);       // When DTR used for PTT control. Go low when CW is over.
  if ((CQ_Repeat_RadioGroup.ItemIndex = 1) and (Contest_Mode_RadioGroup.ItemIndex = 0) and In_CQ and (not(Manual_CW_Stopped))) then
  begin
    CQ_Repeat_Timer.Enabled := True;
  end
  else Manual_CW_Stopped := False;
end;

procedure TMain_Form.StopCW;
begin
  if Assigned(FCWThread) then
    begin
         CQ_Repeat_Timer.Enabled := False;
         FCWThread.Terminate;
    end;
end;

procedure TMain_Form.UDP_KeepAlive_Timer_OnTimer(Sender: TObject);
begin
  Sock.Connect('127.0.0.1','6798');
  Sock.SendString(IntToStr(DateTimeToUnix(Now)));
  DebugLn('KeepAlive Sent: ' + IntToStr(DateTimeToUnix(Now)));
end;

// Uses the system's tick count for accurate delay timing
procedure TCWThread.PreciseSleep(ms: Integer);
var
  Target: QWord;
begin
  Target := GetTickCount64 + QWord(ms);
  while (GetTickCount64 < Target) and (not Terminated) do
    Sleep(1);
end;
procedure TCWThread.SendDit_DTR;
begin
  FSerial.SetDTR(True);
  PreciseSleep(FDitLenPtr^);
  FSerial.SetDTR(False);
  PreciseSleep(FDitLenPtr^);
end;

procedure TCWThread.SendDah_DTR;
begin
  FSerial.SetDTR(True);
  PreciseSleep(FDitLenPtr^ * 3);
  FSerial.SetDTR(False);
  PreciseSleep(FDitLenPtr^);
end;

procedure TCWThread.SendDit_RTS;
begin
  FSerial.SetRTS(True);
  PreciseSleep(FDitLenPtr^);
  FSerial.SetRTS(False);
  PreciseSleep(FDitLenPtr^);
end;

procedure TCWThread.SendDah_RTS;
begin
  FSerial.SetRTS(True);
  PreciseSleep(FDitLenPtr^ * 3);
  FSerial.SetRTS(False);
  PreciseSleep(FDitLenPtr^);
end;

procedure TCWThread.Execute;
var
  i, j: Integer;
  code: string;
begin
  if (Main_Form.Keyer_Mode_RadioGroup.ItemIndex = 2) then
  begin
    FSerial.SetRTS(True);            // Must be toggled True inside thread, which assigns a new TLazSerial
    Sleep(50);                       // Delay between PTT and first DTR toggle is added
    FSerial.SetDTR(True);
  end
  else if (Main_Form.Keyer_Mode_RadioGroup.ItemIndex = 3) then
  begin
    FSerial.SetDTR(True);            // Must be toggled True inside thread, which assigns a new TLazSerial
    Sleep(50);                       // Delay between PTT and first DTR toggle is added
    FSerial.SetRTS(True);
  end;
  for i := 1 to Length(FText) do
  begin
    if Terminated then Exit;
    if FText[i] = ' ' then
    begin
      PreciseSleep(FDitLenPtr^ * 3);
      Continue;
    end;
    code := MorseCode[FText[i]];
    for j := 1 to Length(code) do
    begin
      if Terminated then Exit;
      if code[j] = '.' then
         if (Main_Form.Keyer_Mode_RadioGroup.ItemIndex = 2) then SendDit_DTR else SendDit_RTS
      else
          if (Main_Form.Keyer_Mode_RadioGroup.ItemIndex = 2) then SendDah_DTR else SendDah_RTS;
    end;
    PreciseSleep(FDitLenPtr^ * 2);
  end;
end;

// Invoked only to send CW with Serial port DTR.
procedure TMain_Form.SendMorseText(const msg: string);
begin
  if Assigned(FCWThread) then Exit;             // Thread is already running, do not start another thread.
  FCWThread := TCWThread.Create(msg, @DitLen, LazSerial);
  FCWThread.OnTerminate := @CWThreadTerminated;
  Sleep(100);                       // Delay between end of DTR toggle and PTT toggle is added
//  LazSerial.SetRTS(False);            // Only place it can be toggled to False, since it includes when CW sending is interrupted
end;

procedure TMain_Form.Socket_Receive_Timer_Ontimer(Sender: TObject);
begin

end;

procedure TMain_Form.Keyer_Mode_RadioGroupClick(Sender: TObject);     // This is actually OnChange
begin
 if (LazSerial.Active = True) then LazSerial.Close;
 if (Keyer_Mode_RadioGroup.ItemIndex = 0) then
 begin
      Serial_Configure_Button.Enabled := False;
      Contest_Mode_RadioGroup.Enabled := False;
      CW_Speed_GroupBox.Enabled := False;
      CQ_Repeat_RadioGroup.Enabled := False;
      CW_Macros_GroupBox.Enabled := False;
//      FnKeys_Display_StringGrid.Enabled := False;
 end
 else if (Keyer_Mode_RadioGroup.ItemIndex = 1) then
 begin
      Serial_Configure_Button.Caption := 'Connect via USB';
      Serial_Configure_Button.Enabled := True;
 end
 else if (Keyer_Mode_RadioGroup.ItemIndex in [2..3]) then
 begin
     Serial_Configure_Button.Caption := 'Connect to COM Port';
     Serial_Configure_Button.Enabled := True;
 end;
end;


procedure TMain_Form.CW_Phrase_Edit_ButtonClick(Sender: TObject);
begin
  {$IFDEF MSWindows}
    OpenDocument('.\CW_Macros.txt');
  {$ELSE}
    OpenDocument('./CW_Macros.txt');
  {$ENDIF}
end;

procedure TMain_Form.CW_Speed_SpinEditChange(Sender: TObject);
var
  Speed_Str: String;
begin
    if (Keyer_Mode_RadioGroup.ItemIndex = 1) then       // Winkeyer
    begin
         Speed_Str := IntToStr(CW_Speed_SpinEdit.Value);
         if Length(Speed_Str) = 1 then Speed_Str := '0' + Speed_Str;        // Format the WinKeyer command to send
         LazSerial.WriteData(Chr(2) + Chr(CW_Speed_SpinEdit.Value));         // Set CW speed into Winkeyer
    end
    else if (Keyer_Mode_RadioGroup.ItemIndex in [2..3]) then      // DTR line
    begin
       DitLen := Calculate_Morse_Speed(CW_Speed_SpinEdit.Value);
    end;
end;

procedure TMain_Form.Contest_Mode_RadioGroupClick(Sender: TObject);
begin
  Fill_FnKeys_Display_StringGrid();
end;

procedure TMain_Form.CQ_Repeat_Delay_SpinEdit_OnChange(Sender: TObject);
var
  In_Repeat: Boolean = False;
begin
  if (CQ_Repeat_Timer.Enabled = True) then In_Repeat := True;
  CQ_Repeat_Timer.Enabled := False;
  CQ_Repeat_Timer.Interval := CQ_Repeat_Delay_SpinEdit.Value;
  if (In_Repeat) then CQ_Repeat_Timer.Enabled := True;
end;


procedure TMain_Form.CQ_Repeat_RadioGroup_OnClick(Sender: TObject);         // Triggered when value changed
begin
end;

// Checks that Winkeyer has finished transmitting the CW message
procedure TMain_Form.WinKeyer_Busy_Check_OnTimer(Sender: TObject);
var
  Status_Byte: Byte = 0;
begin
  WinKeyer_Busy_Check_Timer.Enabled := False;
  while (LazSerial.DataAvailable()) do LazSerial.ReadData;    // Flush any leftover status bytes
  LazSerial.WriteData(Chr(21));              // Request for status byte from WinKeyer
  while not (LazSerial.DataAvailable()) do;
  Status_Byte :=  Byte(LazSerial.ReadData[1]);
  DebugLn(binStr(Status_Byte, 8));
  if ((Status_Byte and %11000100) <> %11000000) then WinKeyer_Busy_Check_Timer.Enabled := True              // WinKeyer not finished
  else begin
    CQ_Repeat_Timer.Enabled := True;   // WinKeyer finished sending, start delay timer
  end;
end;

procedure TMain_Form.CQ_Repeat_Timer_OnTimer(Sender: TObject);
begin
  CQ_Repeat_Timer.Enabled := False;
  Send_FnKey_CW('1F1');
  if (Keyer_Mode_RadioGroup.ItemIndex = 1) then WinKeyer_Busy_Check_Timer.Enabled := True; // Winkeyer mode
end;

// This function fills in the CW messages in the displayed StringGrid
procedure TMain_Form.Fill_FnKeys_Display_StringGrid();
var
  CWMess_File: TextFile;
  Line_Str: String;
  Line_Str_List: TStringList;
  col, row: Integer;
begin
   Line_Str_List := TStringList.Create;            // Create an array of strings using comma as delimiter
   Line_Str_List.StrictDelimiter := True;   // do NOT treat spaces as delimiters
   Line_Str_List.Delimiter := ',';
   AssignFile(CWMess_File, 'CW_Macros.txt');
   try
     reset(CWMess_File);    //Reopen the file for reading
     while not eof(CWMess_File) do
     begin
          readln(CWMess_File, Line_Str);
          if ((StartsStr('1F',Line_Str)) or (StartsStr('2F',Line_Str))) then        // Filter out lines that do not begin with 1 or 2
          begin
              try
                Line_Str_List.DelimitedText := Line_Str;   // Parse the read line into an array
              except
              end;
              if (Contest_Mode_RadioGroup.ItemIndex = (StrToInt(Line_Str_List[0][1]) - 1)) then    // Only analyze a line that starts with the same mode number as the selected contest mode
              begin
                  col := (StrToInt(Copy(Line_Str_List[0],3,2)) - 1) Mod 4;  // Calculate the column and row numbers of the StringGrid cell to update
                  row := trunc((StrToInt(Copy(Line_Str_List[0],3,2)) - 1) / 4);
                  FnKeys_Display_StringGrid.Cells[col,row] := 'F' + Copy(Line_Str_List[0],3,2) + ': ' + Line_Str_List[1];  // Create the label into the StringGrid
              end;
          end;
     end;
   finally
     CloseFile(CWMess_File)
   end;
   Application.ProcessMessages;
end;

procedure TMain_Form.Switch_Language(Sender: TObject);
begin
          Main_Form.Caption := sForm1_Caption[Language];
          Contest_Mode_RadioGroup.Caption := sForm1_Contest_Mode_RadioGroup_Caption[Language];
          CW_Speed_GroupBox.Caption := sForm1_CW_Speed_GroupBox_Caption[Language];
          Morse_Speed_Label.Caption := sForm1_Morse_Speed_Label_Caption[Language];
          CQ_Repeat_RadioGroup.Caption := sForm1_CQ_Repeat_RadioGroup_Caption[Language];
          CQ_Repeat_Delay_Label.Caption := sForm1_CQ_Repeat_Delay_Label_Caption[Language];
          CW_Macros_GroupBox.Caption := sForm1_CW_Macros_GroupBox_Caption[Language];
          CW_Phrase_Edit_Button.Caption := sForm1_Keyer_CW_Phrase_Edit_Button_Caption[Language];
          Keyer_Mode_RadioGroup.Caption := sForm1_Keyer_Mode_RadioGroup_Caption[Language];
          Keyer_Mode_RadioGroup.Items[0] := sForm1_Keyer_Mode_RadioGroup_Items_0[Language];
          Keyer_Mode_RadioGroup.Items[1] := sForm1_Keyer_Mode_RadioGroup_Items_1[Language];
          Keyer_Mode_RadioGroup.Items[2]:= sForm1_Keyer_Mode_RadioGroup_Items_2[Language];
          Keyer_Mode_RadioGroup.Items[3]:= sForm1_Keyer_Mode_RadioGroup_Items_3[Language];
          Serial_Configure_Button.Caption := sForm1_Serial_Configure_Button_Caption[Language];
end;

procedure TMain_Form.Form_OnCreate(Sender: TObject);
var
  Lines: TStringList;
  QPLog_Config_Filename: String;
begin
    // Connect to UDP broadcast address with socket to receive QPLog messages.
  Sock := TUDPBlockSocket.Create;
  Sock.Bind('127.0.0.1','6799');                    // listen port
  Fill_FnKeys_Display_StringGrid();
  FnKeys_Display_StringGrid.FixedGridLineColor := clsilver;
  InitMorseTable;                                 // Populate morse lookup table
  Contest_Mode_RadioGroup.Enabled := False;
  CW_Speed_GroupBox.Enabled := False;
  CQ_Repeat_RadioGroup.Enabled := False;
  CW_Macros_GroupBox.Enabled := False;
  FnKeys_Display_StringGrid.Enabled := False;
  Socket_Receive_Timer.Enabled := True;
  // Load language selection from QPLog session config file. If no file found, will load French by default.
  Lines := TStringList.Create;
  QPLog_Config_Filename := 'Session.cfg';
  try
    if FileExists(QPLog_Config_Filename) then Lines.LoadFromFile(QPLog_Config_Filename);
    if Lines.Count >= 17 then
    begin
      if StartsStr('1', Lines[16]) then Language := 1 else Language := 0;
      Switch_Language(nil);
    end;
  finally
    Lines.Free;
  end;
  {$IFDEF MSWINDOWS}
  TimeBeginPeriod(1);
  {$ENDIF}
//  RestoreFormState;                     // Restore main window location and size, and program configuration

end;

procedure TMain_Form.Send_FnKey_CW(FNKey: String);
var
  CWMess_File: TextFile;
  Line_Str: String;
  Final_CW_Mess: String;
  Line_Str_List: TStringList;
begin
  AssignFile(CWMess_File, 'CW_Macros.txt');
  try
    reset(CWMess_File);    //Reopen the file for reading
    while not eof(CWMess_File) do
    begin
         readln(CWMess_File, Line_Str);
         Line_Str := upcase(Line_Str);       // Convert line string to uppercase
         if (((StartsStr('1F',Line_Str)) or (StartsStr('2F',Line_Str))) and (AnsiStartsText(FNKey,Line_Str))) then
         begin
             DebugLn(Line_Str);
             Break;
         end;
    end;
  finally
    CloseFile(CWMess_File)
  end;
  Line_Str_List := TStringList.Create;            // Create an array of strings using comma as delimiter
  try
     Line_Str_List.StrictDelimiter := True;   // do NOT treat spaces as delimiters
     Line_Str_List.Delimiter := ',';
     Line_Str_List.DelimitedText := Line_Str;
  except
  end;
  Final_CW_Mess := Line_Str_List[2];
  Final_CW_Mess := StringReplace(Final_CW_Mess,'{THEIRCALL}', THEIRCALL,[rfReplaceAll, rfIgnoreCase]);
  Final_CW_Mess := StringReplace(Final_CW_Mess,'{MYCALL}', MYCALL,[rfReplaceAll, rfIgnoreCase]);
  Final_CW_Mess := StringReplace(Final_CW_Mess,'{EXCH}', EXCH,[rfReplaceAll, rfIgnoreCase]);
  if (Final_CW_Mess <> '') then
  begin
       Application.ProcessMessages;
       if (Keyer_Mode_RadioGroup.ItemIndex = 1) then                         // Winkeyer mode
       begin
            LazSerial.WriteData(Final_CW_Mess);         // Send Morse data to Winkeyer
            if ((CQ_Repeat_RadioGroup.ItemIndex = 1) and (Contest_Mode_RadioGroup.ItemIndex = 0) and (In_CQ = True)) then WinKeyer_Busy_Check_Timer.Enabled := True;
       end
       else if (Keyer_Mode_RadioGroup.ItemIndex in [2..3]) then          // DTR line toggle mode
       begin
          SendMorseText(Final_CW_Mess);
       end;
  end;
  DebugLn('CW Message sent: ' + Final_CW_Mess);
  Line_Str_List.free();
end;

procedure TMain_Form.Socket_Receive_OnTimer(Sender: TObject);
var
  rx_string, rx_substring: String;
  FKey_Label: String;
  Rx_Command_List: TStringList;
  Key_Pressed: Integer;
begin
  Socket_Receive_Timer.Enabled := False;
  rx_string := '';
  if Sock.CanRead(0) then
        begin
             rx_substring := Sock.RecvPacket(0);
             rx_string := rx_string + rx_substring;
        end;
  if rx_string <> '' then DebugLn(rx_string);
  if ((length(rx_string) > 0) and (rx_string[1] = '{') and (rx_string[length(rx_string)] = '}')) then
  begin
       // convert string into an array of strings
       Rx_Command_List := TStringList.Create;
      try
        Rx_Command_List.StrictDelimiter := True;   // do NOT treat spaces as delimiters
        Rx_Command_List.Delimiter := ',';
        Rx_Command_List.DelimitedText := rx_string;
      except
      end;
      MYCALL := Rx_Command_List[6];
      THEIRCALL := Rx_Command_List[2];
      EXCH := Rx_Command_List[7];
      // Decode received message
      Key_Pressed := StrToInt(Rx_Command_List[1]);   // An integer corresponding to the ASCII code of the key that was pressed.
      DebugLn('Key_Pressed: ' + IntToStr(Key_Pressed));
      if (Key_Pressed = 27) then      // Escape key
      begin
          if (Keyer_Mode_RadioGroup.ItemIndex = 1) then
          begin
            WinKeyer_Busy_Check_Timer.Enabled := False;
            CQ_Repeat_Timer.Enabled := False;
            LazSerial.WriteData(Chr(10));          // Send a Clear Buffer request which immediately stops CW sending by Keyer
          end
          else if (Keyer_Mode_RadioGroup.ItemIndex in [2..3]) then
          begin
            StopCW();
            CQ_Repeat_Timer.Enabled := False;
            Manual_CW_Stopped := True;
            In_CQ := False;
          end;
          DebugLn('CW stop executed');
      end
      else if (Key_Pressed = 13) then                     // Return key. Will send CQ if in Run (CQ) mode.
      begin
           if (Contest_Mode_RadioGroup.ItemIndex = 0) then          // Run mode
           begin
                if ((Length(Rx_Command_List[2]) < 3) and (Length(Rx_Command_List[4]) < 2)) then
                begin
                  In_CQ := True;
                  Send_FnKey_CW('1F1');
                end
                else if ((Length(Rx_Command_List[2]) >= 3) and (Length(Rx_Command_List[4]) < 2)) then
                begin
                  In_CQ := False;
                  Send_FnKey_CW('1F2')
                end
                else if ((Length(Rx_Command_List[2]) >= 3) and (Length(Rx_Command_List[4]) >= 2)) then
                begin
                  In_CQ := False;
                  Send_FnKey_CW('1F3');
                end;
           end
           else if (Contest_Mode_RadioGroup.ItemIndex = 1) then        // S&P mode
           begin
                 In_CQ := False;
                 if ((Length(Rx_Command_List[2]) < 3) or (Length(Rx_Command_List[4]) < 2)) then Send_FnKey_CW('2F1')
                 else if ((Length(Rx_Command_List[2]) >= 3) and (Length(Rx_Command_List[4]) >= 2)) then Send_FnKey_CW('2F2');
           end;
           Manual_CW_Stopped := False;
      end
      // Create the function key line label
      else if (Key_Pressed in [111..122]) then      // Function key pressed
      begin
        FKey_Label := IntToStr(Contest_Mode_RadioGroup.ItemIndex + 1) + 'F' +  IntToStr((Key_Pressed) - 111);
        DebugLn(FKey_Label);
        if ((Contest_Mode_RadioGroup.ItemIndex = 0) and (FKey_Label = '1F1')) then In_CQ := True   // and (CQ_Repeat_RadioGroup.ItemIndex = 1)
        else In_CQ := False;
        Manual_CW_Stopped := False;
        Send_FnKey_CW(FKey_Label);
      end;
  rx_string := '';
  end;
  Socket_Receive_Timer.Enabled := True;
end;


procedure TMain_Form.Serial_Configure_ButtonClick(Sender: TObject);
begin
  if (Keyer_Mode_RadioGroup.ItemIndex <> 0) then
  begin
    LazSerial.ShowSetupDialog;
    LazSerial.Open;
    LazSerial.SetDTR(False);
    LazSerial.SetRTS(False);
    Serial_Configure_Button.Enabled := False;
    if (Keyer_Mode_RadioGroup.ItemIndex = 1) then
    begin
      Screen.Cursor := crHourglass;
      Application.ProcessMessages;
      Sleep(5000);
      Screen.Cursor := crDefault;
      Application.ProcessMessages;
      LazSerial.WriteData(Chr(0) + Chr(2));              // Open admin interface  (mandatory!)
      FnKeys_Display_StringGrid.Enabled := True;
    end
    else if (Keyer_Mode_RadioGroup.ItemIndex in [2..3]) then
    begin

    end;
    Contest_Mode_RadioGroup.Enabled := True;
    CW_Speed_GroupBox.Enabled := True;
    CQ_Repeat_RadioGroup.Enabled := True;
    CW_Macros_GroupBox.Enabled := True;
    FnKeys_Display_StringGrid.Enabled := True;
  end;
end;


end.

